<?php
class Database
{   
    private $host = "localhost";
    private $db_name = "schoolpos";
    private $username = "schoolpos";
    private $password = "schoolpos";
    public $conn;
     
    public function dbConnection()
	{
     
	    $this->conn = null;    
        try
		{
            $this->conn = new PDO("mysql:host=" . $this->host . ";dbname=" . $this->db_name, $this->username, $this->password);
			$this->conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);	
        }
		catch(PDOException $exception)
		{
            echo "Connection error: " . $exception->getMessage();
        }
         
        return $this->conn;
    }
}
?>
<?php

class MANOSOFT
{	
private $conn;
	public function __construct()
	{
		$database = new Database();
		$db = $database->dbConnection();
		$this->conn = $db;
    }
	
	public function runQuery($sql)
	{
		$stmt = $this->conn->prepare($sql);
		return $stmt;
	}
}
?>
<?php
	
$g = new MANOSOFT();
	$token = 'manoSoft_gdhed745i489uhfbvbndjnur773w6re';
	$items = '2017-01-10';	
	
	$stmt = $g->runQuery("SELECT * FROM phppos_modules_items WHERE token=:token");
	$stmt->execute(array(":token"=>$token));
	
	$w=$stmt->fetch(PDO::FETCH_ASSOC);                        
if($w['token'] != $token && $w['items' != $itmes]  ) 
			{
			header("Location: ../../error.php");
}else{
         echo 'Welcome!!! Emerald British School. Your Licence is ACTIVE(Powered by Manomite Technology).';
}






?>