<?php
session_start();
if(!isset($_SESSION['auth_session']))
{
	header("Location: ../../index.php");
}

include_once 'config.php';

$stmt = $db_con->prepare("SELECT * FROM auth_users WHERE user_id=:uid");
$stmt->execute(array(":uid"=>$_SESSION['auth_session']));
$auth_row=$stmt->fetch(PDO::FETCH_ASSOC);

?>