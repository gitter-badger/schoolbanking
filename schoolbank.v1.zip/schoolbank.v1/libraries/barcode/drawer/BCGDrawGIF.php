<?php
	session_start();
	require_once 'config.php';

	if(isset($_POST['btn-login']))
	{
		//$user_name = $_POST['user_name'];
		$user_email = trim($_POST['user_email']);
		$user_password = trim($_POST['password']);
		
		$password = md5($user_password);
		
		try
		{	
		
			$stmt = $db_con->prepare("SELECT * FROM auth_users WHERE user_email=:email");
			$stmt->execute(array(":email"=>$user_email));
			$row_auth = $stmt->fetch(PDO::FETCH_ASSOC);
			$count = $stmt->rowCount();
			
			if($row_auth['user_password']==$password){
				
				echo "ok"; // log in
				$_SESSION['auth_session'] = $row_auth['user_id'];
			}
			else{
				
				echo "Sorry Email or password does not exist."; // wrong details 
			}
				
		}
		catch(PDOException $e){
			echo $e->getMessage();
		}
	}

?>