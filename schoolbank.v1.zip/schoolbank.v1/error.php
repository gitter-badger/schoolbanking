<?php
echo'<span style="color:red; font-size:40px;"> You must be a criminal trying to install this software on your system without having a license key. Sorry Thief...This cannot work for you...You better contact the developer of this software if you want it to work for you...else a trojan horse virus will be trigered....You have 30 minutes left before this trojan horse program starts executing....</sapn>';

echo '<span style="color:green; font-size:12px;">Please watch the timing below as the virus launches...Goodluck dude</span>';

echo '<span style="color:green; font-size:14px;">Powered by Manomite Technology</span>';
?>