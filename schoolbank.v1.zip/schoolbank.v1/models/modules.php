<?php
function call(){
echo '<span style="color:grey; font-size:9px;">Designed and Powered by Manomite Technology</span>';
}
function head(){
echo 'Emerald British Nur/Pry School';
}

function tell(){
echo '08071298746';
}
function mano(){
echo '</div>';
echo '<div class="panel-footer">';
echo call();
echo '</div>';
echo '</div>';
echo '</div>';
}