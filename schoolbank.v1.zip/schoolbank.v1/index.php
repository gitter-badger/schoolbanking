<?php
/**
 * Manomite Technology Schoolbank Software Solution
 *
 * An open source application development framework for PHP
 *
 * This content is released under the MIT License (MIT)
 *
 * Copyright (c) 2016 - 2018, British Columbia Institute of Technology
 *
 * Permission is hereby granted, for paid versions, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software with restriction, including with limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to disable persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 *
 * @package	manomite technology
 * @author	Adeyeye George
 * @copyright	Copyright (c) 2016 - 2018, Manomite Technology, Inc. (http://www.manomite.net/)
 * @copyright	Copyright (c) 2016 - 2018, British Columbia Institute of Technology (http://bcit.ca/)
 * @since	Version 1.0.0
 * @filesource
 */

/*
 *---------------------------------------------------------------
 * APPLICATION ENVIRONMENT
 *---------------------------------------------------------------
 *
 * You can load different configurations depending on your
 * current environment. Setting the environment also influences
 * things like logging and database settings.
 *
 * This can be set to anything, but default usage is:
 *
 *     database = schoolpos
 *    username = schoolpos
 *    password = pschoolpos
 *
 */
 session_start();

if(isset($_SESSION['auth_session'])!="")
{
	header("Location: schoolbank/index/");
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<title>Welcome to Emerald British College</title>
 <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
<script src="schoolbank/jquery-1.11.3-jquery.min.js"></script>
<script src="schoolbank/dist/js/loading.js"></script>
<link href="schoolbank/dist/css/loading.css" rel="stylesheet">


<link href="schoolbank/bootstrap/css/bootstrap.min.css" rel="stylesheet" media="screen">
<script type="text/javascript" src="schoolbank/jquery-1.11.3-jquery.min.js"></script>
<script type="text/javascript" src="validation.min.js"></script>
<link href="style.css" rel="stylesheet" type="text/css" media="screen">
<script type="text/javascript" src="script.js"></script>
</head>

<body>
   <div class="loader"></div>
<div class="signin-form">

	<div class="container">
     <span style="float:inherit; position:absolute; top:5%; left:45%; text-align:center; border-radius:10 15px 5px; letter-spacing:5px"><img src="schoolbank/img/header_logo.png" height="100px" border-radius="50px" width="100px"></span>
      
       <form class="form-signin" method="post" id="login-form">
        
        <h2 class="form-signin-heading">Log In to Emerald School Bank.</h2><hr />
        
        <div id="error">
        <!-- error will be shown here ! -->
        </div>
        
        <div class="form-group">
        <input type="email" class="form-control" placeholder="Email address" name="user_email" id="user_email" />
        <span id="check-e"></span>
        </div>
        
        <div class="form-group">
        <input type="password" class="form-control" placeholder="Password" name="password" id="password" />
        </div>
       
     	<hr />
        
        <div class="form-group">
            <button type="submit" class="btn btn-default" name="btn-login" id="btn-login">
    		<span class="glyphicon glyphicon-log-in"></span> &nbsp; Login
			</button> 
        </div>  
      
      </form><br><br>
  <span style="float:inherit; position:absolute; font-weight:900; left:36%; text-align:center; border-radius:10 15px 5px; color:#000066; letter-spacing:5px"><a href="http://www.manomite.net">Powered By Manomite Technology</a></span>
      
    </div>
    
</div>
    
<script src="schoolbank/bootstrap/js/bootstrap.min.js"></script>

</body>
</html>

