-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Dec 09, 2016 at 06:33 PM
-- Server version: 10.1.16-MariaDB
-- PHP Version: 5.6.24

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `schoolpos`
--

-- --------------------------------------------------------

--
-- Table structure for table `application`
--

CREATE TABLE `application` (
  `staff_id` int(11) NOT NULL,
  `fname` varchar(100) NOT NULL,
  `address` varchar(255) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `employment_date` varchar(15) NOT NULL,
  `department` varchar(40) NOT NULL,
  `qualification` varchar(40) NOT NULL,
  `file_no` varchar(15) NOT NULL,
  `designation` varchar(40) NOT NULL,
  `documents` varchar(255) NOT NULL,
  `passport` varchar(255) NOT NULL,
  `application_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `auth_users`
--

CREATE TABLE `auth_users` (
  `user_id` int(11) NOT NULL,
  `user_name` varchar(25) NOT NULL,
  `user_email` varchar(60) NOT NULL,
  `user_password` varchar(255) NOT NULL,
  `joining_date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `auth_users`
--

INSERT INTO `auth_users` (`user_id`, `user_name`, `user_email`, `user_password`, `joining_date`) VALUES
(1, 'Manomite', 'admin@gmail.com', 'aff03abc31767cd6d8fb46409f77a14c', '2016-12-10 08:52:10');

-- --------------------------------------------------------

--
-- Table structure for table `general_ledger`
--

CREATE TABLE `general_ledger` (
  `item_id` int(11) NOT NULL,
  `item_name` varchar(100) NOT NULL,
  `category` varchar(100) NOT NULL,
  `item_cost` varchar(100) NOT NULL,
  `quantity` varchar(20) NOT NULL,
  `total` varchar(255) NOT NULL,
  `bought_by` varchar(15) NOT NULL,
  `date` varchar(100) NOT NULL,
  `serial` varchar(15) NOT NULL,
  `registered_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `loan`
--

CREATE TABLE `loan` (
  `trans_id` varchar(255) NOT NULL,
  `loan_id` int(11) NOT NULL,
  `fname` varchar(100) NOT NULL,
  `date1` varchar(100) NOT NULL,
  `amount` varchar(100) NOT NULL,
  `sign_of_the_receiver` varchar(20) NOT NULL,
  `loan_authorized` varchar(15) NOT NULL,
  `sign_of_authourity` varchar(100) NOT NULL,
  `date` varchar(100) NOT NULL,
  `application_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `status` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `loan_paid`
--

CREATE TABLE `loan_paid` (
  `loan_id` int(11) NOT NULL,
  `trans_id` varchar(255) NOT NULL,
  `fname` varchar(100) NOT NULL,
  `date2` varchar(100) NOT NULL,
  `amount_of_loan_obtained` varchar(100) NOT NULL,
  `amount_paid` varchar(20) NOT NULL,
  `loan_returned` varchar(15) NOT NULL,
  `sign_of_receiving_officer` varchar(100) NOT NULL,
  `date` varchar(15) NOT NULL,
  `debt_owed` varchar(100) NOT NULL,
  `status` varchar(100) NOT NULL,
  `application_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `phppos_modules_items`
--

CREATE TABLE `phppos_modules_items` (
  `id` int(11) NOT NULL,
  `keys` varchar(15) NOT NULL,
  `token` varchar(40) NOT NULL,
  `date_generated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `items_date` varchar(40) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `phppos_modules_items`
--

INSERT INTO `phppos_modules_items` (`id`, `keys`, `token`, `date_generated`, `items_date`) VALUES
(1, 'ManoSoft', 'manoSoft_gdhed745i489uhfbvbndjnur773w6re', '2016-11-12 00:29:16', '2017-01-10');

-- --------------------------------------------------------

--
-- Table structure for table `phppos_modules_reference`
--

CREATE TABLE `phppos_modules_reference` (
  `id` int(11) NOT NULL,
  `teller_id` varchar(15) NOT NULL,
  `trans_id` varchar(40) NOT NULL,
  `amount_paid` varchar(40) NOT NULL,
  `actual_amount` varchar(40) NOT NULL,
  `purpose` varchar(40) NOT NULL,
  `depositor_name` varchar(100) NOT NULL,
  `depositor_phone` varchar(15) NOT NULL,
  `depositor_address` varchar(100) NOT NULL,
  `paying_for` varchar(100) NOT NULL,
  `session` varchar(50) NOT NULL,
  `class` varchar(50) NOT NULL,
  `date_payed` varchar(40) NOT NULL,
  `teller_file` varchar(255) NOT NULL,
  `date_uploaded` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `total` varchar(40) NOT NULL,
  `dept` varchar(15) NOT NULL,
  `token` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `pupils`
--

CREATE TABLE `pupils` (
  `pupil_id` int(11) NOT NULL,
  `app_id` varchar(100) NOT NULL,
  `date` varchar(100) NOT NULL,
  `pupil_name` varchar(100) NOT NULL,
  `class` varchar(100) NOT NULL,
  `session` varchar(20) NOT NULL,
  `fees` varchar(15) NOT NULL,
  `description` varchar(1000) NOT NULL,
  `total` varchar(15) NOT NULL,
  `final` varchar(255) NOT NULL,
  `year` varchar(15) NOT NULL,
  `passport` varchar(100) NOT NULL,
  `registered_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `salary`
--

CREATE TABLE `salary` (
  `salary_id` int(11) NOT NULL,
  `fname` varchar(100) NOT NULL,
  `month` varchar(100) NOT NULL,
  `amount` varchar(100) NOT NULL,
  `deductions` varchar(20) NOT NULL,
  `real_salary` varchar(100) NOT NULL,
  `date` varchar(15) NOT NULL,
  `sig` varchar(100) NOT NULL,
  `application_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `sales`
--

CREATE TABLE `sales` (
  `sales_id` int(11) NOT NULL,
  `app_id` varchar(100) NOT NULL,
  `item_name` varchar(100) NOT NULL,
  `serial` varchar(100) NOT NULL,
  `category` varchar(20) NOT NULL,
  `cost_price` varchar(15) NOT NULL,
  `selling_price` varchar(100) NOT NULL,
  `quantity` varchar(15) NOT NULL,
  `interest` varchar(15) NOT NULL,
  `total` varchar(255) NOT NULL,
  `amount_paid` varchar(255) NOT NULL,
  `buyer_name` varchar(255) NOT NULL,
  `date` varchar(100) NOT NULL,
  `registered_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `service_provider`
--

CREATE TABLE `service_provider` (
  `service_id` int(11) NOT NULL,
  `app_id` varchar(100) NOT NULL,
  `date` varchar(100) NOT NULL,
  `session` varchar(100) NOT NULL,
  `sname` varchar(20) NOT NULL,
  `serp` varchar(15) NOT NULL,
  `amc` varchar(100) NOT NULL,
  `amp` varchar(15) NOT NULL,
  `balance` varchar(15) NOT NULL,
  `registered_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `teller_id` varchar(15) NOT NULL,
  `trans_id` varchar(40) NOT NULL,
  `amount_paid` varchar(40) NOT NULL,
  `actual_amount` varchar(40) NOT NULL,
  `purpose` varchar(40) NOT NULL,
  `depositor_name` varchar(100) NOT NULL,
  `depositor_phone` varchar(15) NOT NULL,
  `depositor_address` varchar(100) NOT NULL,
  `paying_for` varchar(100) NOT NULL,
  `session` varchar(50) NOT NULL,
  `class` varchar(50) NOT NULL,
  `date_payed` varchar(40) NOT NULL,
  `year` varchar(255) NOT NULL,
  `teller_file` varchar(255) NOT NULL,
  `date_uploaded` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `total` varchar(40) NOT NULL,
  `dept` varchar(15) NOT NULL,
  `token` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `application`
--
ALTER TABLE `application`
  ADD PRIMARY KEY (`staff_id`);

--
-- Indexes for table `auth_users`
--
ALTER TABLE `auth_users`
  ADD PRIMARY KEY (`user_id`);

--
-- Indexes for table `general_ledger`
--
ALTER TABLE `general_ledger`
  ADD PRIMARY KEY (`item_id`);

--
-- Indexes for table `loan`
--
ALTER TABLE `loan`
  ADD PRIMARY KEY (`loan_id`);

--
-- Indexes for table `loan_paid`
--
ALTER TABLE `loan_paid`
  ADD PRIMARY KEY (`loan_id`);

--
-- Indexes for table `phppos_modules_items`
--
ALTER TABLE `phppos_modules_items`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `phppos_modules_reference`
--
ALTER TABLE `phppos_modules_reference`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pupils`
--
ALTER TABLE `pupils`
  ADD PRIMARY KEY (`pupil_id`);

--
-- Indexes for table `salary`
--
ALTER TABLE `salary`
  ADD PRIMARY KEY (`salary_id`);

--
-- Indexes for table `sales`
--
ALTER TABLE `sales`
  ADD PRIMARY KEY (`sales_id`);

--
-- Indexes for table `service_provider`
--
ALTER TABLE `service_provider`
  ADD PRIMARY KEY (`service_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `application`
--
ALTER TABLE `application`
  MODIFY `staff_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;
--
-- AUTO_INCREMENT for table `auth_users`
--
ALTER TABLE `auth_users`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `general_ledger`
--
ALTER TABLE `general_ledger`
  MODIFY `item_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `loan`
--
ALTER TABLE `loan`
  MODIFY `loan_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `loan_paid`
--
ALTER TABLE `loan_paid`
  MODIFY `loan_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `phppos_modules_items`
--
ALTER TABLE `phppos_modules_items`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `phppos_modules_reference`
--
ALTER TABLE `phppos_modules_reference`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT for table `pupils`
--
ALTER TABLE `pupils`
  MODIFY `pupil_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `salary`
--
ALTER TABLE `salary`
  MODIFY `salary_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `sales`
--
ALTER TABLE `sales`
  MODIFY `sales_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `service_provider`
--
ALTER TABLE `service_provider`
  MODIFY `service_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
