<?php		 						
$servername = "localhost";
$username = "schoolpos";
$password = "schoolpos";
$dbname = "schoolpos";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT fname FROM loan";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    echo '<select class="form-control" name="fname">';
    // output data of each row
    while($row = $result->fetch_assoc()) {
								
                                      
                                           
											   echo '<option>'; echo $row['fname']; echo '</option>';
                                             
                                              }
											  }else{
											  echo '<option>No Staff Recorded Yet</option>';
											  }
                                            echo '</select>';
										
											?>
											 <div class="form-group has-success">
                                            <label class="control-label" for="inputSuccess">Date</label>
                                            <input type="text" placeholder="Enter Date" name="date" class="form-control" id="Text1">
                                        </div>    
                                         <div class="form-group has-success">
                                            <label class="control-label" for="inputSuccess">Amout Paid</label>
                                            <input type="text" placeholder="NGN10000" name="paid" class="form-control" id="Text4">
                                        </div>
                                         <div class="form-group has-success">
                                            <label class="control-label" for="inputSuccess">Loan Returned to:(Name)</label>
                                            <input type="text" placeholder="Use name for signature" name="lll" class="form-control" id="Text5">
                                        </div>
                                       
                                </div>
                                <!-- /.col-lg-6 (nested) -->
                                <div class="col-lg-6">
                                 
                                        <div class="form-group has-success">
                                            <label class="control-label" for="inputSuccess">Signature of Receiving Officer</label>
                                            <input type="text" placeholder="Use name for signature" name="siga" class="form-control" id="Text5">
                                        </div>
                                         
                                          <div class="form-group has-success">
                                            <label class="control-label" for="inputSuccess">Date</label>
                                            <input type="text" placeholder="Date" name="ddd2" class="form-control" id="Text5">
                                        </div>
                                   