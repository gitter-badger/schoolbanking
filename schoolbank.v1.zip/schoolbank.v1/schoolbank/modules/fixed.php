<?php
			
            echo '<div class="row">';
                echo'<div class="col-lg-12">';
                    echo '<div class="panel panel-primary">';
                        echo '<div class="panel-heading">';
                          echo "Fixed Items Recorded Table";
                       echo" </div>";

                        echo '<div id="table" class="panel-body">';
						
						
$servername = "localhost";
$username = "schoolpos";
$password = "schoolpos";
$dbname = "schoolpos";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
$f = "Fixed";

$sql = "SELECT item_id,item_name,category,item_cost,quantity,total,bought_by,date,serial FROM general_ledger WHERE category='Fixed'";
$result = $conn->query($sql);

if($result->num_rows > 0) {
            
    echo "<table class='table table-bordered'><thead><tr><th>S/N</th><th>Item Name</th><th>Item Category</th><th>Item Cost</th><th>Qantity</th><th>Total</th><th>Bought By</th><th>Date</th><th>Serial</th></tr></thead>";
    // output data of each row
    while($row = $result->fetch_assoc()) {
    echo '<tbody><tr><th scope="row">'; echo $row["item_id"]; echo '</th>'; echo '<td>'; echo $row["item_name"]; echo '</td>'; echo '<td>'; echo $row["category"]; echo '</td>'; echo '<td>'; echo "NGN"; echo $row["item_cost"]; echo '</td>'; echo '<td>'; echo $row["quantity"]; echo '</td>'; echo '<td>'; echo "NGN"; echo $row["total"]; echo '</td>'; echo '<td>'; echo $row["bought_by"]; echo '</td>'; echo '<td>'; echo $row["date"]; echo '</td>'; echo '<td>'; echo $row["serial"]; echo '</td>'; echo '</tr>'; echo '</tbody>';
    }
    echo "</table>";
	
} else {
    print "No Item recorded yet<br><br>";
}
$sql2 = "SELECT SUM(total) AS ttt FROM general_ledger WHERE category='Fixed'";
$result2 = $conn->query($sql2);
$r = $result2->fetch_assoc();
 $e = $r['ttt'];
 $sum = $e;

echo "<span style='color:grey;font-size:24; font-weight:900;'>"; echo "TOTAL---------------:";echo '</span>'; echo "<span style='color:red; font-size:24; font-weight:900;'>"; echo "NGN"; echo $sum; echo '</span>';
						
							echo '</div>';
							
                            echo '<div class="well">';
                                echo '<h4>'.'Copyrights'.'</h4>';
                                echo "<p>This table uses token to generate datas. Do not tamper with this token or allow unauthorized person to tamper with it to avoid errors. If tampered please...click the button below</p>";
                               echo '<a class="btn btn-default btn-lg btn-block" target="_blank" href="mailto:gestech11@gmail.com">Contact ManoSoft</a>';
                            echo "</div>";
                       echo" </div>";
                     
                    echo "</div>";

                echo "</div>";
           echo " </div>";
		   ?>