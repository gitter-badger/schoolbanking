<?php
			
            echo '<div class="row">';
                echo'<div class="col-lg-12">';
                    echo '<div class="panel panel-primary">';
                        echo '<div class="panel-heading">';
                          echo "STAFF PROFILE";
                       echo" </div>";

                        echo '<div id="table" class="panel-body">';
						
						
$servername = "localhost";
$username = "schoolpos";
$password = "schoolpos";
$dbname = "schoolpos";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT staff_id, fname, phone, employment_date, department FROM application";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    echo "<table class='table table-bordered'><thead><tr><th>S/N</th><th>Staff Name</th><th>Phone Number</th><th>Employment Date</th><th>Department</th><th>Details</th><th>Others</th></tr></thead>";
    // output data of each row
    while($row = $result->fetch_assoc()) {
        echo '<tbody><tr><th scope="row">'; echo $row["staff_id"]; echo '</th>'; echo '<td>'; echo $row["fname"]; echo '</td>'; echo '<td>'; echo $row["phone"]; echo '</td>'; echo '<td>'; echo $row["employment_date"]; echo '</td>'; echo '<td>'; echo $row["department"]; echo '</td>'; echo '<td>'; echo '<a href=../index/details.php?view=';echo $row["staff_id"]; echo '>View</a>'; echo '</td>'; echo '</td>';  echo '<td>'; echo '<a href=../index/delete.php?delete=';echo $row["staff_id"]; echo '>Delete</a>'; echo '</td>'; echo '</tr>'; echo '</tbody>';
    }
    echo "</table>";
} else {
    print "No Datas of staff provided yet";
}
$conn->close();

						
							echo '</div>';
							
                            echo '<div class="well">';
                                echo '<h4>'.'Copyrights'.'</h4>';
                                echo "<p>This table uses token to generate datas. Do not tamper with this token or allow unauthorized person to tamper with it to avoid errors. If tampered please...click the button below</p>";
                               echo '<a class="btn btn-default btn-lg btn-block" target="_blank" href="mailto:gestech11@gmail.com">Contact ManoSoft</a>';
                            echo "</div>";
                       echo" </div>";
                     
                    echo "</div>";

                echo "</div>";
           echo " </div>";
		   ?>