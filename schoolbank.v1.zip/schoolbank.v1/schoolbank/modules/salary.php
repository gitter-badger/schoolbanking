<?php		 						
$servername = "localhost";
$username = "schoolpos";
$password = "schoolpos";
$dbname = "schoolpos";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT fname FROM application";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    echo '<select class="form-control" name="fname">';
    // output data of each row
    while($row = $result->fetch_assoc()) {
								
                                      
                                           
											   echo '<option>'; echo $row['fname']; echo '</option>';
                                             
                                              }
											  }else{
											  echo '<option>No Staff Recorded Yet</option>';
											  }
                                            echo '</select>';
										
											?>