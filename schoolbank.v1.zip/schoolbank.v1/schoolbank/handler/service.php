<?php
    require_once("../../config/token.php");
	require_once("../../models/modules.php");
	
require_once('../handler/class.service.php');
$serve = new SERVICE();

if(isset($_POST['serve']))
{  
	$date = strip_tags($_POST['date']);
	$sess = strip_tags($_POST['ses']);
	$sname = strip_tags($_POST['sname']);		
	$serp = strip_tags($_POST['serp']);
	$amc = strip_tags($_POST['amc']);
	$amp = strip_tags($_POST['amp']);	
	
	if($date=="")	{
		$error[] = "Please provide Date !";	
	}
	else if($sess=="Select Session")	{
		$error[] = "Please Select Session !";	
	}
	else if($sname=="")	{
		$error[] = "Please provide Service Provider Name !";	
	}
	else if($serp=="")	{
		$error[] = "Please provide Service Provided !";
	}
	else if($amc=="")	{
		$error[] = "Please provide Amount Charged !";
	}
	else if($amp=="")	{
		$error[] = "Please provide Amount Paid !";	
	}
	
	else{
	       $bal = $amc - $amp;
		
	      function serve($len = 6){
                $r = '';
                $chars = array_merge(range('0', '9'));
                $max = count($chars) - 1;
                for($i = 0; $i<$len; $i++){
               $rand = mt_rand(0, $max);
               $r .= $chars[$rand];
              }
                 return $r;
}
            $appe = serve();

	         if($serve->service($appe,$date,$sess,$sname,$serp,$amc,$amp,$bal)){
			  $serve->redir_s('../index/service/index.php?id='.$appe.'');			 
}
			}
		}
		
		
?>