<?php
							
if(isset($_POST['search'])){
$servername = "localhost";
$username = "schoolpos";
$password = "schoolpos";
$dbname = "schoolpos";
$conn = mysqli_connect($servername, $username, $password, $dbname);
if(!$conn)
{
die("connection failed:" . mysqli_connect_error());
}
$tra = $_POST['s'];
if($tra=="")	{
		$error[] = "Please provide transaction ID !";	
	}else{
$sql = "SELECT trans_id FROM users WHERE trans_id='$tra'";
			$stmt = $conn->query($sql);
			$row=$stmt->fetch_assoc();
	$kid = $row['trans_id'];
	 $_SESSION['tra'] = $kid;
	 if($_SESSION['tra'] != ""){
$ti = $_SESSION['tra']; 
					echo '<a type="button" class="btn btn-warning" href=../index/updated.php?id='.$ti.">Slip Found: Click to see Details</a>";

}
					else{
          $error[] = "Sorry No transaction ID Found !";
}

}
}
?>
