<?php

require_once('config.php');

class LOAN
{	
private $conn;
	public function __construct()
	{
		$database = new Database();
		$db = $database->dbConnection();
		$this->conn = $db;
    }
	
	public function runQuery($sql)
	{
		$stmt = $this->conn->prepare($sql);
		return $stmt;
	}
	
	public function loan($tok,$fname,$date1,$amount,$rs,$lau,$sau,$date)
	{
		try
		{
			
			$stmt = $this->conn->prepare("INSERT INTO loan(trans_id,fname,date1,amount,sign_of_the_receiver,loan_authorized,sign_of_authourity,date) 
		                                               VALUES(:t, :f, :d, :a, :s, :l, :sg, :dd)");
			$stmt->bindparam(':t',$tok);
			$stmt->bindparam(':f',$fname);
			$stmt->bindparam(':d',$date1);
                $stmt->bindparam(':a',$amount);
			$stmt->bindparam(':s',$rs);
			$stmt->bindparam(':l',$lau);
			$stmt->bindparam(':sg',$sau);
			$stmt->bindparam(':dd',$date);
          						  	
			$stmt->execute();	
			
			return $stmt;	
		}
		catch(PDOException $e)
		{
			echo $e->getMessage();
		}				
	}	
	public function redir_loan($url)
	{
		header("Location: $url");
	}
	
}
?>