<?php
    require_once("../../config/token.php");
	require_once("../../models/modules.php");
	
require_once('../handler/class.loan.php');
$loan = new LOAN();

if(isset($_POST['oya']))
{  
	$fname = strip_tags($_POST['fname']);
	$date1 = strip_tags($_POST['date1']);
	$amount = strip_tags($_POST['aloan']);	
	$rs = strip_tags($_POST['sig']);
	$lau = strip_tags($_POST['author']);
	$sau = strip_tags($_POST['siga']);
	$date = strip_tags($_POST['ddd']);	
	
	if($fname=="")	{
		$error[] = "Please provide Staff Name !";	
	}
	if($date1=="")	{
		$error[] = "Please provide loan Date !";	
	}
	else if($amount=="")	{
		$error[] = "Please provide Loan Amount !";	
	}
	else if($rs=="")	{
		$error[] = "Please provide Signature of the receiver !";
	}
	else if($lau=="")	{
		$error[] = "Please provide loan Authourize !";	
	}
	else if($sau=="")	{
		$error[] = "Please provide Signature of Authority !";
	}
	else if($date=="")	{
		$error[] = "Please loan collection date !";
	}
	
	else{
		try
		{
			$stmt = $loan->runQuery("SELECT fname, date FROM loan WHERE fname=:fe && date=:dd ");
			$stmt->execute(array(':fe'=>$fname, ':dd'=>$date1));
			$row=$stmt->fetch(PDO::FETCH_ASSOC);
				
			if($row['fname']==$fname && $row['date']==$date ) {
				$error[] = "Sorry!!! this staff cannot collect loan twice uisng the same date !";
			}
			else
			{ 
			    function man($len = 5){
                $r = '';
                $chars = array_merge(range('A', 'Z'),range('a', 'z'),range('0', '9'));
                $max = count($chars) - 1;
                for($i = 0; $i<$len; $i++){
               $rand = mt_rand(0, $max);
               $r .= $chars[$rand];
              }
                 return $r;
}
            $tok = man();

	         if($loan->loan($tok,$fname,$date1,$amount,$rs,$lau,$sau,$date)){
			 
              $loan->redir_loan('../index/invoice/index.php?inv='.$tok.'');


				}
			}
		}
		catch(PDOException $e)
		{
			echo $e->getMessage();
		}
	}	
}

?>