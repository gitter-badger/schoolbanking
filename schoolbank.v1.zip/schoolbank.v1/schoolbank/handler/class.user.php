<?php

require_once('config.php');

class MANOSOFT
{	
private $conn;
	public function __construct()
	{
		$database = new Database();
		$db = $database->dbConnection();
		$this->conn = $db;
    }
	
	public function runQuery($sql)
	{
		$stmt = $this->conn->prepare($sql);
		return $stmt;
	}
	
	public function register($teller_id,$trans_id,$amount_paid,$actual_amount,$purpose,$depositor_name,$depositor_phone,$depositor_address,$paying_for,$session,$class,$date_payed,$yr,$total,$dept,$token,$status)
	{
		try
		{
			$new = password_hash($token, PASSWORD_DEFAULT);
			
			$stmt = $this->conn->prepare("INSERT INTO users(teller_id,trans_id,amount_paid,actual_amount,purpose,depositor_name,depositor_phone,depositor_address,paying_for,session,class,date_payed,year,total,dept,token,status) 
		                                               VALUES(:tid, :trid, :amp, :acp, :p, :dep, :depp, :dad, :pf, :ses, :cl, :dp, :yr, :tt, :dept, :tok, :st)");
							
			$stmt->bindparam(':tid',$teller_id);
			$stmt->bindparam(':trid',$trans_id);
                $stmt->bindparam(':amp',$amount_paid);
			$stmt->bindparam(':acp',$actual_amount);
			$stmt->bindparam(':p',$purpose);
                $stmt->bindparam(':dep',$depositor_name);
                $stmt->bindparam(':depp',$depositor_phone);
                $stmt->bindparam(':dad',$depositor_address);
			$stmt->bindparam(':pf',$paying_for);					
			$stmt->bindparam(':ses', $session);
                $stmt->bindparam(':cl', $class);
			$stmt->bindparam(':dp', $date_payed);
			$stmt->bindparam(':yr', $yr);	
				
                $stmt->bindparam(':tt', $total);
			$stmt->bindparam(':dept', $dept);	
                	$stmt->bindparam(':tok', $new);	
                	$stmt->bindparam(':st', $status);										  	
			$stmt->execute();	
			
			return $stmt;	
		}
		catch(PDOException $e)
		{
			echo $e->getMessage();
		}				
	}
	
	
	public function tile($trans_id,$teller_id,$teller_file)
	{
		try
		{
			
			$stmt = $this->conn->prepare("INSERT INTO tellers(trans_id,teller_no,teller_file) 
		                                               VALUES(:ti, :t, :tri)");
							
			$stmt->bindparam(':ti',$trans_id);
			$stmt->bindparam(':t',$teller_id);
			$stmt->bindparam(':tri',$teller_file);
              								  	
			$stmt->execute();	
			
			return $stmt;	
		}
		catch(PDOException $e)
		{
			echo $e->getMessage();
		}				
	}
	public function don($pup_name,$classe)
	{
		try
		{
			$stmt = $this->conn->prepare("SELECT pupil_id, pupil_name, class FROM pupils WHERE pupil_name=:pp OR class=:cc ");
			$stmt->execute(array(':pp'=>$pup_name, ':cc'=>$classe));
			$userRow=$stmt->fetch(PDO::FETCH_ASSOC);
			if($stmt->rowCount() == 1)
			{
				
					$_SESSION['user_session'] = $userRow['pupil_id'];
					return true;
				}
				else
				{
					return false;
				}
			
		}
		catch(PDOException $e)
		{
			echo $e->getMessage();
		}
	}
	
	public function is_loggedin()
	{
		if(isset($_SESSION['user_session']))
		{
			return true;
		}
	}
	public function redirect($url)
	{
		header("Location: $url");
	}
	
	public function doLogout()
	{
		session_destroy();
		return true;
	}
}
?>