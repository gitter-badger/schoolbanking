<?php

require_once('config.php');

class SERVICE
{	
private $conn;
	public function __construct()
	{
		$database = new Database();
		$db = $database->dbConnection();
		$this->conn = $db;
    }
	
	public function runQuery($sql)
	{
		$stmt = $this->conn->prepare($sql);
		return $stmt;
	}
	
	public function service($appe,$date,$sess,$sname,$serp,$amc,$amp,$bal)
	{
		try
		{
			
			$stmt = $this->conn->prepare("INSERT INTO service_provider(app_id,date,session,sname,serp,amc,amp,balance) 
		                                               VALUES(:app, :dt, :ss, :sn, :se, :am, :ap, :ba)");
			$stmt->bindparam(':app',$appe);
			$stmt->bindparam(':dt',$date);
			$stmt->bindparam(':ss',$sess);
			$stmt->bindparam(':sn',$sname);
            $stmt->bindparam(':se',$serp);
			$stmt->bindparam(':am',$amc);
			$stmt->bindparam(':ap',$amp);
			$stmt->bindparam(':ba',$bal);
			
			$stmt->execute();	
			
			return $stmt;	
		}
		catch(PDOException $e)
		{
			echo $e->getMessage();
		}				
	}	
	public function redir_s($url)
	{
		header("Location: $url");
	}
	
}
?>