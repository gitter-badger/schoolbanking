<?php
    require_once("../../config/token.php");
	require_once("../../models/modules.php");
	
require_once('../handler/class.sales.php');
$s = new SALES();

if(isset($_POST['sales']))
{  
	$itn = strip_tags($_POST['itn']);
	$upc= strip_tags($_POST['upc']);
	$cate = strip_tags($_POST['cate']);		
	$cpp = strip_tags($_POST['cpp']);
	$spp = strip_tags($_POST['spp']);
	$quan = strip_tags($_POST['quan']);	
	$amtp = strip_tags($_POST['amtp']);
	$buy = strip_tags($_POST['buyer_name']);	
	$date = strip_tags($_POST['date']);	
	
	if($itn=="")	{
		$error[] = "Please provide Item Name !";	
	}
	else if($cate=="")	{
		$error[] = "Please Provide Category !";	
	}
	else if($cpp=="")	{
		$error[] = "Please Provide Cost Price !";	
	}
	else if($spp=="")	{
		$error[] = "Please Provide Selling Price !";
	}
	else if($quan=="")	{
		$error[] = "Please Provide Quantity !";
	}
	else if($amtp=="")	{
		$error[] = "Please Provide Amount Paid for Items !";
	}
	else if($buy=="")	{
		$error[] = "Please Provide Buyer Name !";
	}
	else if($date=="")	{
		$error[] = "Please provide Date!";	
	}
	
	else{
	       $int = $spp - $cpp;
		   $total = $quan * $spp;
		
	      function sell($len = 6){
                $r = '';
                $chars = array_merge(range('0', '9'));
                $max = count($chars) - 1;
                for($i = 0; $i<$len; $i++){
               $rand = mt_rand(0, $max);
               $r .= $chars[$rand];
              }
                 return $r;
}
            $sell = sell();

	         if($s->sales($sell,$itn,$upc,$cate,$cpp,$spp,$quan,$int,$total,$amtp,$buy,$date)){
			  $s->redir_sales('../index/sales/index.php?id='.$sell.'');			 
}
			}
		}
		
		
?>