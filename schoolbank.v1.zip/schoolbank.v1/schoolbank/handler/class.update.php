<?php

require_once('config.php');

class UPDATE
{	
private $conn;
	public function __construct()
	{
		$database = new Database();
		$db = $database->dbConnection();
		$this->conn = $db;
    }
	
	public function runQuery($sql)
	{
		$stmt = $this->conn->prepare($sql);
		return $stmt;
	}
	
	public function update($teller_id,$trans_id,$amount_paid,$actual_amount,$purpose,$depositor_name,$depositor_phone,$depositor_address,$paying_for,$session,$class,$date_payed,$teller_file,$total,$dept,$token)
	{
		try
		{
					
			$stmt = $this->conn->prepare("INSERT INTO phppos_modules_reference(teller_id,trans_id,amount_paid,actual_amount,purpose,depositor_name,depositor_phone,depositor_address,paying_for,session,class,date_payed,teller_file,total,dept,token) 
		                                               VALUES(:tid, :trid, :amp, :acp, :p, :dep, :depp, :dad, :pf, :ses, :cl, :dp, :tf, :tt, :dept, :tok)");
							
			$stmt->bindparam(':tid',$teller_id);
			$stmt->bindparam(':trid',$trans_id);
                $stmt->bindparam(':amp',$amount_paid);
			$stmt->bindparam(':acp',$actual_amount);
			$stmt->bindparam(':p',$purpose);
                $stmt->bindparam(':dep',$depositor_name);
                $stmt->bindparam(':depp',$depositor_phone);
                $stmt->bindparam(':dad',$depositor_address);
			$stmt->bindparam(':pf',$paying_for);					$stmt->bindparam(':ses', $session);
                $stmt->bindparam(':cl', $class);
			$stmt->bindparam(':dp', $date_payed);	
                $stmt->bindparam(':tf', $teller_file);
                $stmt->bindparam(':tt', $total);
			$stmt->bindparam(':dept', $dept);	
                	$stmt->bindparam(':tok', $token);										  	
			$stmt->execute();	
			
			return $stmt;	
		}
		catch(PDOException $e)
		{
			echo $e->getMessage();
		}				
	}	
	public function redirect($url)
	{
		header("Location: $url");
	}
	
	public function doLogout()
	{
		session_destroy();
		return true;
	}
}
?>