<?php
	session_start();
	unset($_SESSION['auth_session']);
	
	if(session_destroy())
	{
		header("Location: ../../index.php");
	}
?>