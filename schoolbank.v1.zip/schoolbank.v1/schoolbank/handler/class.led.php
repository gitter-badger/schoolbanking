<?php

require_once('config.php');

class LED
{	
private $conn;
	public function __construct()
	{
		$database = new Database();
		$db = $database->dbConnection();
		$this->conn = $db;
    }
	
	public function runQuery($sql)
	{
		$stmt = $this->conn->prepare($sql);
		return $stmt;
	}
	
	public function led($itname,$cat,$cost,$quant,$q,$bought,$date,$serial)
	{
		try
		{
			
			$stmt = $this->conn->prepare("INSERT INTO general_ledger(item_name,category,item_cost,quantity,total,bought_by,date,serial) 
		                                               VALUES(:it, :c, :i, :qu, :o, :bb, :di, :sss)");
			$stmt->bindparam(':it',$itname);
			$stmt->bindparam(':c',$cat);
			$stmt->bindparam(':i',$cost);
                $stmt->bindparam(':qu',$quant);
				 $stmt->bindparam(':o',$q);
			$stmt->bindparam(':bb',$bought);
			$stmt->bindparam(':di',$date);
			$stmt->bindparam(':sss',$serial);
          						  	
			$stmt->execute();	
			
			return $stmt;	
		}
		catch(PDOException $e)
		{
			echo $e->getMessage();
		}				
	}	
	public function redir_led($url)
	{
		header("Location: $url");
	}
	
}
?>