<?php
    require_once("../../config/token.php");
	require_once("../../models/modules.php");
	
require_once('../handler/class.laps.php');
$laps = new LAPS();

         if(isset($_GET['staff-name'])){
		
	     $id = $_GET['staff-name'];
		 $_SESSION['id'] = $id;
	     $stmt = $laps->runQuery("SELECT * FROM loan WHERE trans_id=:ffff");
	      $stmt->execute(array(":ffff"=>$_SESSION['id']));
	      $userRow=$stmt->fetch(PDO::FETCH_ASSOC);
		  
		  if($userRow['status'] == "completed loan Payment"){
		  $manomite['token'] = "Congratulations!!! you have completed your loan";
		  }else{
		            $stmt = $laps->runQuery("SELECT * FROM loan_paid WHERE trans_id=:fo");
	      $stmt->execute(array(":fo"=>$_SESSION['id']));
	      $urow=$stmt->fetch(PDO::FETCH_ASSOC);
			
			$see = $userRow['amount'] - $urow['amount_paid'];
			
		          $manomite['token'] = "You are owing the sum of NGN".$see." loan debt";
				  }

if(isset($_POST['pay']))
{  
    $trans = $userRow['trans_id'];
	$fname = $userRow['fname'];
	$date2 = strip_tags($_POST['date2']);
	$amt_ob = $userRow['amount'];	
	$amt_paid = strip_tags($_POST['paid']);
	$ret_to = strip_tags($_POST['ret']);
	$rsig = strip_tags($_POST['rsig']);
	$date = strip_tags($_POST['dddd']);	
	
	if($fname=="")	{
		$error[] = "Please provide Staff Name !";	
	}
	if($date2=="")	{
		$error[] = "Please provide loan payment Date !";	
	}
	else if($amt_paid=="")	{
		$error[] = "Please provide Amount paid !";
	}
	else if($ret_to=="")	{
		$error[] = "Please provide Name of Loan Collector !";	
	}
	else if($rsig=="")	{
		$error[] = "Please provide Signature of receiving officer!";
	}
	else if($date=="")	{
		$error[] = "Please loan payment date !";
	}
	
	else{
		try
		{
		  $stmt = $laps->runQuery("SELECT * FROM loan_paid WHERE trans_id=:fo");
	      $stmt->execute(array(":fo"=>$_SESSION['id']));
	      $row=$stmt->fetch(PDO::FETCH_ASSOC);
			
			
			if($row['trans_id'] == $_SESSION['id']){
			 if($row['status'] == "completed loan Payment"){
		            
		  $error[] = "Sorry!!! Staff having Loan Transaction ID ".$_SESSION['id']." has completed his/her loan.!";
		  }else{
			$total = $amt_paid + $row['amount_paid'];
			$debt = $userRow['amount'] - $total;
			$zero = "0";
			if($debt != $zero) {
			 $status = "Incomplete loan Payment";
			 }else{
			   $status = "completed loan Payment";
		  
		 	
			    $stmt4 = $laps->runQuery("UPDATE loan SET status=:sta WHERE trans_id=:a");
	      $stmt4->execute(array(':sta'=>$status, ':a'=>$_SESSION['id']));
			   }
			    $update = ("UPDATE loan_paid SET date2=:dat, amount_paid=:amt, loan_returned=:tot, sign_of_receiving_officer=:sref, date=:da, debt_owed=:deb, status=:stt WHERE trans_id=:a");
// Prepare statement
$stm = $laps->runQuery($update);
// execute the query
$stm->execute(array(':dat'=>$date2, ':amt'=>$total, ':tot'=>$ret_to, ':sref'=>$rsing, ':da'=>$date, ':deb'=>$debt, ':stt'=>$status, ':a'=>$_SESSION['id']));
             $laps->redir_laps('../index/invoice/receipt.php?invo='.$trans.'');
			 }
				}else{
				$debt = $userRow['amount'] - $amt_paid;
				$zero = "0";
			   if($debt != $zero) {
			 $status = "Incomplete loan Payment";
			 }else{
			   $status = "completed loan Payment";
			   }
			   
			  
				 if($laps->laps($trans,$fname,$date2,$amt_ob,$amt_paid,$ret_to,$rsig,$date,$debt,$status)){	
             $laps->redir_laps('../index/invoice/receipt.php?invo='.$trans.'');
			 }
			 }
			 }
			 

		catch(PDOException $e)
		{
			echo $e->getMessage();
		}
	}	
}
}

?>