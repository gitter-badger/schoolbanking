<?php
    require_once("../../config/token.php");
	require_once("../../models/modules.php");
	
require_once('../handler/class.led.php');
$led = new LED();

               if(isset($_GET['view'])){
		
	           $v = $_GET['view'];
           $stmt = $led->runQuery("SELECT * FROM application WHERE staff_id=:st");
	      $stmt->execute(array(":st"=>$v));
	       $u=$stmt->fetch(PDO::FETCH_ASSOC);
		   $servername = "localhost";

$username = "schoolpos";
$password = "schoolpos";
$dbname = "schoolpos";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
echo "<span style='color:green; font-size:18; font-weight:900;'>Loan Collected Account Table</span>";
$sql = "SELECT trans_id,loan_id,fname,date1,amount,sign_of_the_receiver,loan_authorized,sign_of_authourity,date FROM loan WHERE fname='".$u['fname']."'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {

 echo "<table class='table table-bordered'><thead><tr><th>S/N</th><th>Transaction ID</th><th>Staff Name</th><th>Date</th><th>Amount</th><th>Receiver Signature</th><th>Loan Authourized</th><th>Sign of Authority</th><th>Date</th></tr></thead>";
    // output data of each row
    while($row = $result->fetch_assoc()) {
        echo '<tbody><tr><th scope="row">'; echo $row["loan_id"]; echo '</th>'; echo '<td>'; echo $row["trans_id"]; echo '</td>'; echo '<td>'; echo $row["fname"]; echo '</td>'; echo '<td>'; echo $row["date1"]; echo '</td>'; echo '<td>'; echo $row["amount"]; echo '</td>'; echo '<td>'; echo $row["sign_of_the_receiver"]; echo '</td>'; echo '<td>'; echo $row["loan_authorized"]; echo '</td>';  echo '<td>'; echo $row["sign_of_authourity"]; echo '</td>'; echo '<td>'; echo $row["date"]; echo '</td>'; echo '</tr>'; echo '</tbody>';
    }
    echo "</table>";
} else {
    print "No Datas of loan provided yet";
}
echo "<hr><br><br><br><hr>";
echo "<span style='color:green; font-size:18; font-weight:900;'>Loan Payment Account Table</span>";
$sql2 = "SELECT loan_id,trans_id,fname,date2,amount_of_loan_obtained,amount_paid,loan_returned,sign_of_receiving_officer,date,debt_owed,status FROM loan_paid WHERE fname='".$u['fname']."'";
$result2 = $conn->query($sql2);

if ($result2->num_rows > 0) {

 echo "<table class='table table-bordered'><thead><tr><th>S/N</th><th>Transaction ID</th><th>Staff Name</th><th>Date</th><th>Amount Obtained</th><th>Amount Paid</th><th>Loan Returned</th><th>Sign of Receiving Officer</th><th>Date</th><th>Debt Owed</th><th>Status</th></tr></thead>";
    // output data of each row
    while($row2 = $result2->fetch_assoc()) {
        echo '<tbody><tr><th scope="row">'; echo $row2["loan_id"]; echo '</th>'; echo '<td>'; echo $row2["trans_id"]; echo '</td>'; echo '<td>'; echo $row2["fname"]; echo '</td>'; echo '<td>'; echo $row2["date2"]; echo '</td>'; echo '<td>'; echo $row2["amount_of_loan_obtained"]; echo '</td>'; echo '<td>'; echo $row2["amount_paid"]; echo '</td>'; echo '<td>'; echo $row2["loan_returned"]; echo '</td>';  echo '<td>'; echo $row2["sign_of_receiving_officer"]; echo '</td>'; echo '<td>'; echo $row2["date"]; echo '</td>'; echo '<td>'; echo $row2["debt_owed"]; echo '</td>';  echo '<td>'; echo $row2["status"]; echo '</td>'; echo '</tr>'; echo '</tbody>';
    }
    echo "</table>";
} else {
    print "No Datas of paid loan provided yet";
}
echo "<hr><br><br><br><hr>";
echo "<span style='color:green; font-size:18; font-weight:900;'>Salary Account Table</span>";
$sql3 = "SELECT salary_id,fname,month,amount,deductions,real_salary,date,sig FROM salary WHERE fname='".$u['fname']."'";
$result3 = $conn->query($sql3);

if ($result3->num_rows > 0) {

 echo "<table class='table table-bordered'><thead><tr><th>Salary ID</th><th>Staff Name</th><th>Month</th><th>Amount</th><th>Deductions</th><th>Balance</th><th>Date</th><th>Signature</th></tr></thead>";
    // output data of each row
    while($row3 = $result3->fetch_assoc()) {
        echo '<tbody><tr><td scope="row">'; echo $row3["salary_id"]; echo '</td>'; echo '<td>'; echo $row3["fname"]; echo '</td>';  echo '<td>'; echo $row3["month"]; echo '</td>';echo '<td>'; echo $row3["amount"]; echo '</td>'; echo '<td>'; echo $row3["deductions"]; echo '</td>'; echo '<td>'; echo $row3["real_salary"]; echo '</td>'; echo '<td>'; echo $row3["date"]; echo '</td>';  echo '<td>'; echo $row3["sig"]; echo '</td>'; echo '</tr>'; echo '</tbody>';
    }
    echo "</table>";
} else {
    print "No Salary paid to satff yet";
}
$conn->close();
echo "<hr><br><br><br><hr>";
}else{

 print "No Session set";
 }



	         
			
?>