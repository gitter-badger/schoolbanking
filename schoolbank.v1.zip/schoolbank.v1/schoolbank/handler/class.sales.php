<?php

require_once('config.php');

class SALES
{	
private $conn;
	public function __construct()
	{
		$database = new Database();
		$db = $database->dbConnection();
		$this->conn = $db;
    }
	
	public function runQuery($sql)
	{
		$stmt = $this->conn->prepare($sql);
		return $stmt;
	}
	
	public function sales($sell,$itn,$upc,$cate,$cpp,$spp,$quan,$int,$total,$amtp,$buy,$date)
	{
		try
		{
			
			$stmt = $this->conn->prepare("INSERT INTO sales(app_id,item_name,serial,category,cost_price,selling_price,quantity,interest,total,amount_paid,buyer_name,date) 
		                                               VALUES(:appp, :it, :sss, :cate, :co, :se, :qu, :in, :tt, :amm, :bu, :de)");
			$stmt->bindparam(':appp',$sell);
			$stmt->bindparam(':it',$itn);
			$stmt->bindparam(':sss',$upc);
			$stmt->bindparam(':cate',$cate);
            $stmt->bindparam(':co',$cpp);
			$stmt->bindparam(':se',$spp);
			$stmt->bindparam(':qu',$quan);
			$stmt->bindparam(':in',$int);
			$stmt->bindparam(':tt',$total);
			$stmt->bindparam(':amm',$amtp);
			$stmt->bindparam(':bu',$buy);
			$stmt->bindparam(':de',$date);
			
			$stmt->execute();	
			
			return $stmt;	
		}
		catch(PDOException $e)
		{
			echo $e->getMessage();
		}				
	}	
	public function redir_sales($url)
	{
		header("Location: $url");
	}
	
}
?>