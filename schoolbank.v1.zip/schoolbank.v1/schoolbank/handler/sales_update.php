<?php
    require_once("../../config/token.php");
	require_once("../../models/modules.php");
	
require_once('../handler/class.sales.php');
$s = new SALES();


if(isset($_GET['sales'])){
$sale = $_GET['sales'];

           $stmt = $s->runQuery("SELECT * FROM sales WHERE app_id=:ap");
	      $stmt->execute(array(":ap"=>$sale));
	      $userRow=$stmt->fetch(PDO::FETCH_ASSOC);

if(isset($_POST['sales_update']))
{  
	$amtp = strip_tags($_POST['amtp']);	
	$date = strip_tags($_POST['date']);	
	
	if($amtp=="")	{
		$error[] = "Please Provide Amount Paid for Items !";
	}
	else if($date=="")	{
		$error[] = "Please provide Date!";	
	}
	
	else{
	    
	       $int = $amtp + $userRow["amount_paid"];
		
$update = ("UPDATE sales SET amount_paid=:apa, date=:dot WHERE app_id=:real");
// Prepare statement
$stm = $s->runQuery($update);
// execute the query
$stm->execute(array(':apa'=>$int, ':dot'=>$date, ':real'=>$userRow['app_id']));
if($stm){
             $s->redir_sales('../index/sales/index.php?id='.$userRow["app_id"].'');
			 }else{
			   $s->redir_sales('sales_update.php?sales='.$userRow["app_id"].'');
			   
			   
			   }
			   }
			   }
			   }
	        
		
		
?>