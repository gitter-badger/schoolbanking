<?php

require_once('config.php');

class APPLICATION
{	
private $conn;
	public function __construct()
	{
		$database = new Database();
		$db = $database->dbConnection();
		$this->conn = $db;
    }
	
	public function runQuery($sql)
	{
		$stmt = $this->conn->prepare($sql);
		return $stmt;
	}
	
	public function apply($fname,$address,$phone,$employment_date,$department,$qualification,$file_no,$designation,$documents,$passport)
	{
		try
		{
			
			$stmt = $this->conn->prepare("INSERT INTO application(fname,address,phone,employment_date,department,qualification,file_no,designation,documents,passport) 
		                                               VALUES(:f, :a, :p, :e, :d, :q, :f_no, :des, :doc, :pass)");
							
			$stmt->bindparam(':f',$fname);
			$stmt->bindparam(':a',$address);
                $stmt->bindparam(':p',$phone);
			$stmt->bindparam(':e',$employment_date);
			$stmt->bindparam(':d',$department);
                $stmt->bindparam(':q',$qualification);
                $stmt->bindparam(':f_no',$file_no);
                $stmt->bindparam(':des',$designation);
			$stmt->bindparam(':doc',$documents);
                $stmt->bindparam(':pass', $passport);								  	
			$stmt->execute();	
			
			return $stmt;	
		}
		catch(PDOException $e)
		{
			echo $e->getMessage();
		}				
	}	
	public function redir_app($url)
	{
		header("Location: $url");
	}
	
}
?>