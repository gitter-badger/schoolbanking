<?php
    session_start();
    require_once("../../config/token.php");
	require_once("../handler/session.php");
	require_once("../../models/modules.php");
	
require_once('../handler/class.update.php');
$user = new MANOSOFT();

if(isset($_POST['update']))
{ 
    	$teller_id = $userRow['teller_id'];
     $trans_id = $userRow['trans_id'];
	$amount_paid = $userRow['amount_paid'];	
	$actual_amount = $userRow['actual_amount'];
	$purpose = $userRow['purpose'];
	$depositor_name = $userRow['depositor_name'];	
	$depositor_phone = $userRow['depositor_phone'];
	$depositor_address = $userRow['depositor_address'];
	$paying_for = $userRow['paying_for'];
	$session = $userRow['depositor_name'];
	$class = $userRow['class'];
	$date_payed = $userRow['date_payed'];
     $teller_file = $userRow['teller_file'];
     $date_uploaded = $userRow['date_uploaded'];
     $total = $userRow['total'];
     $dept = $userRow['dept'];
     $token = $userRow['token'];

   if($user->update($teller_id,$trans_id,$amount_paid,$actual_amount,$purpose,$depositor_name,$depositor_phone,$depositor_address,$paying_for,$session,$class,$date_payed,$teller_file,$date_uploaded,$total,$dept,$token)){

     $tell = strip_tags($_POST['teller_no']);
	$amt_paid = strip_tags($_POST['amp']);	
	$act_amount = $userRow['actual_amount'];
	$pur = strip_tags($_POST['p']);
	$dep_name = strip_tags($_POST['dname']);	
	$dep_phone = strip_tags($_POST['dphone']);	
	$dep_address = strip_tags($_POST['dad']);
	$pay_for = strip_tags($_POST['pf']);
	$classs = strip_tags($_POST['class']);	
	$date = strip_tags($_POST['dp']);
	$cal = $act_amount-$amt_paid;
	$total_t = $amt_paid;
	$debt = $cal;
	if($debt == 0){
	$status = 'completed payments';
	}else{
	$status = 'incomplete payments';
	}
$update = "UPDATE users SET teller_id=".$tell.", amount_paid='$amt_paid', actual_amount='$act_amount', purpose='$pur', depositor_name='$dep_name', depositor_phone='dep_phone', depositor_address='$dep_address', paying_for='$pay_for', class='$classs', date_paid='$date', total='$total_t', $dept='$debt', status='$status'  WHERE trans_id=:t_id" ;
// Prepare statement
$stm = $auth_user->runQuery($sql);
// execute the query
$stm->execute(array(":t_id"=>$userRow['trans_id']));

	
			
					?>