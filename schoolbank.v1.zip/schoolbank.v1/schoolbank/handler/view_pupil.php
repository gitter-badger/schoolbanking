<?php
    require_once("../../config/token.php");
	require_once("../../models/modules.php");
	
require_once('../handler/class.pupils.php');
$vat = new PUPILS();

               if(isset($_GET['id'])){
		
	           $vi = $_GET['id'];
           $stmt = $vat->runQuery("SELECT * FROM pupils WHERE app_id=:app");
	      $stmt->execute(array(":app"=>$vi));
	       $ur=$stmt->fetch(PDO::FETCH_ASSOC);
		  
echo "<span style='color:green; font-size:18; font-weight:900;'>File Table</span>";

 echo "<table class='table table-bordered'><thead><tr><th>S/N</th><th>Transaction ID</th><th>Date</th><th>School Fees</th><th>Description</th><th>Items Fees</th><th>Total</th></tr></thead>";
 
 echo '<tbody><tr><th scope="row">'; echo $ur["pupil_id"]; echo '</th>'; echo '<td>'; echo $ur["app_id"]; echo '</td>'; echo '<td>'; echo $ur["date"]; echo '</td>'; echo '<td>'; echo $ur["fees"]; echo '</td>'; echo '<td>'; echo $ur["description"]; echo '</td>'; echo '<td>'; echo $ur["total"]; echo '</td>'; echo '<td>'; echo $ur["final"]; echo '</td>'; echo '</tr>'; echo '</tbody>';
    
    echo "</table>";
	
	
echo "<hr><br><br><br><hr>";
echo "<span style='color:green; font-size:18; font-weight:900;'>Transaction Table</span>";

           $stmt = $vat->runQuery("SELECT * FROM users WHERE trans_id=:app");
	      $stmt->execute(array(":app"=>$vi));
	       $ure=$stmt->fetch(PDO::FETCH_ASSOC);
		   
		   if($ure["trans_id"]){

 echo "<table class='table table-bordered'><thead><tr><th>S/N</th><th>Transaction ID</th><th>Date Paid</th><th>Amount Paid</th><th>Debt Owed</th><th>Status</th><th>Update</th><th>Teller</tr></thead>";

        echo '<tbody><tr><th scope="row">'; echo $ure["id"]; echo '</th>'; echo '<td>'; echo $ure["trans_id"]; echo '</td>';  echo '<td>'; echo $ure["date_payed"]; echo '</td>'; echo '<td>'; echo "NGN";echo $ure["amount_paid"]; echo '</td>'; echo '<td>'; echo "NGN";echo $ure["dept"]; echo '</td>'; echo '<td>'; echo $ure["status"]; echo '</td>'; echo '<td>';echo "<a href='updated.php?id=".$ure["trans_id"]."'>Update Payment</a>"; echo '</td>'; echo '<td>';  echo "<a href='../index/teller.php?id=".$ure["trans_id"]."'>View Teller</a>"; echo '</td>'; echo '</tr>'; echo '</tbody>';
 
    echo "</table>";

}else{
print "<br><br>";
 print "NO Payment made yet for this pupil";
 }
 }



	         
			
?>