<?php
    require_once("../../config/token.php");
	require_once("../../models/modules.php");
	
require_once('../handler/class.salary.php');
$sala = new SALARY();

if(isset($_POST['wole']))
{  
	$fname = strip_tags($_POST['fname']);
	$month = strip_tags($_POST['month']);
	$amount = strip_tags($_POST['amount']);	
	$deduct = strip_tags($_POST['deduct']);
	$date = strip_tags($_POST['date']);
	$sig = strip_tags($_POST['sig']);	
	
	if($fname=="")	{
		$error[] = "Please provide Staff Name !";	
	}
	else if($amount=="")	{
		$error[] = "Please provide Staff Salary !";	
	}
	else if($deduct=="")	{
		$error[] = "Please provide Staff Deductions or use----NO DEDUCTIONS as value. !";
	}
	else if($date=="")	{
		$error[] = "Please provide Salary Date !";	
	}
	else if($sig=="")	{
		$error[] = "Please provide Signature !";
	}
	
	else{
		try
		{
			$stmt = $sala->runQuery("SELECT fname, date FROM salary WHERE fname=:fn && date=:d ");
			$stmt->execute(array(':fn'=>$fname, ':d'=>$date));
			$row=$stmt->fetch(PDO::FETCH_ASSOC);
				
			if($row['fname']==$fname && $row['date']==$date ) {
				$error[] = "Sorry You cannot pay staff twice uisng the same date !";
			}
			else
			{ 
			    $real_salary = $amount - $deduct;
	         if($sala->salary($fname,$month,$amount,$deduct,$real_salary,$date,$sig)){	
             $sala->redir_sala('../index/Salary.php?registered');


				}
			}
		}
		catch(PDOException $e)
		{
			echo $e->getMessage();
		}
	}	
}

?>