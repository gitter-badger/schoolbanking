<?php

require_once('config.php');

class PUPILS
{	
private $conn;
	public function __construct()
	{
		$database = new Database();
		$db = $database->dbConnection();
		$this->conn = $db;
    }
	
	public function runQuery($sql)
	{
		$stmt = $this->conn->prepare($sql);
		return $stmt;
	}
	
	public function reg($app,$date,$pup,$class,$ses,$fees,$desc,$total,$final,$yr,$passport)
	{
		try
		{
		
			
			$stmt = $this->conn->prepare("INSERT INTO pupils(app_id,date,pupil_name,class,session,fees,description,total,final,year,passport) 
		                                               VALUES(:ap, :d, :p, :c, :s, :f, :dc, :tt, :ff, :y, :pas)");
			$stmt->bindparam(':ap',$app);
			$stmt->bindparam(':d',$date);
			$stmt->bindparam(':p',$pup);
			$stmt->bindparam(':c',$class);
            $stmt->bindparam(':s',$ses);
			$stmt->bindparam(':f',$fees);
			$stmt->bindparam(':dc',$desc);
			$stmt->bindparam(':tt',$total);
			$stmt->bindparam(':ff',$final);
			$stmt->bindparam(':y',$yr);
			$stmt->bindparam(':pas',$passport);
          						  	
			$stmt->execute();	
			
			return $stmt;	
		}
		catch(PDOException $e)
		{
			echo $e->getMessage();
		}				
	}	
	public function redir_pup($url)
	{
		header("Location: $url");
	}
	
}
?>