<?php
    require_once("../../config/token.php");
	require_once("../../models/modules.php");
	
require_once('../handler/class.pupils.php');
$pupe = new PUPILS();

if(isset($_POST['go']))
{  
	$date = strip_tags($_POST['date']);
	$pup = strip_tags($_POST['pname']);
	$class = strip_tags($_POST['class']);		
	$ses = strip_tags($_POST['ses']);
	$fees = strip_tags($_POST['fees']);
	$desc = strip_tags($_POST['desc']);	
	$total = strip_tags($_POST['total']);	
	$yr = strip_tags($_POST['yr']);
	
	if($date=="")	{
		$error[] = "Please provide Date !";	
	}
	else if($pup=="")	{
		$error[] = "Please provide Pupil Name !";	
	}
	else if($class=="Select Class")	{
		$error[] = "Please provide Pupil Class !";	
	}
	else if($ses=="Select Session")	{
		$error[] = "Please provide Select Session !";
	}
	else if($fees=="")	{
		$error[] = "Please provide School Fees !";	
	}
	else if($desc=="")	{
		$error[] = "Please provide Items Descriptions !";
	}
	else if($total=="")	{
		$error[] = "Please provide Item Descriptions Total Amount !";
	}
	else if($yr=="")	{
		$error[] = "Please provide year !";	
	}
	
	else{
		try
		{
			$stmt = $pupe->runQuery("SELECT pupil_name, year FROM pupils WHERE pupil_name=:p ");
			$stmt->execute(array(':p'=>$pup));
			$row=$stmt->fetch(PDO::FETCH_ASSOC);
				
			if($row['pupil_name'] == $pup || $row['session'] == $ses || $row['year'] == $yr) {
				$error[] = "Sorry this pupil has already been registered for this year and session. !";
			}
			else
			{ 
			
	 $file = rand(1000,100000)."-".$_FILES['passport']['name'];
    $file_loc = $_FILES['passport']['tmp_name'];
 $file_size = $_FILES['passport']['size'];
 $file_type = $_FILES['passport']['type'];
 $folder="../handler/pupils/";
 
 // new file size in KB
 $new_size = $file_size/1024;  
 // new file size in KB
 
 // make file name in lower case
 $new_file_name = strtolower($file);
 // make file name in lower case
 
 $passport=str_replace(' ','-',$new_file_name);
  move_uploaded_file($file_loc,$folder.$passport);
	if($passport=="")	{
		$error[] = "Please select Pupil Passport !";	
	} 
	else{
	
	      function pu($len = 8){
                $r = '';
                $chars = array_merge(range('0', '9'));
                $max = count($chars) - 1;
                for($i = 0; $i<$len; $i++){
               $rand = mt_rand(0, $max);
               $r .= $chars[$rand];
              }
                 return $r;
}
            $app = pu();
			
			$final = $fees + $total;

	         if($pupe->reg($app,$date,$pup,$class,$ses,$fees,$desc,$total,$final,$yr,$passport)){
			  $pupe->redir_pup('../index/pup/index.php?id='.$app.'');			 
}
			}
		}
		}
		catch(PDOException $e)
		{
			echo $e->getMessage();
		}
	}	
}

?>