<?php

require_once('config.php');

class SALARY
{	
private $conn;
	public function __construct()
	{
		$database = new Database();
		$db = $database->dbConnection();
		$this->conn = $db;
    }
	
	public function runQuery($sql)
	{
		$stmt = $this->conn->prepare($sql);
		return $stmt;
	}
	
	public function salary($fname,$month,$amount,$deduct,$real_salary,$date,$sig)
	{
		try
		{
			
			$stmt = $this->conn->prepare("INSERT INTO salary(fname,month,amount,deductions,real_salary,date,sig) 
		                                               VALUES(:f, :m, :a, :d, :r, :da, :s)");
							
			$stmt->bindparam(':f',$fname);
			$stmt->bindparam(':m',$month);
                $stmt->bindparam(':a',$amount);
			$stmt->bindparam(':d',$deduct);
			$stmt->bindparam(':r',$real_salary);
			$stmt->bindparam(':da',$date);
			$stmt->bindparam(':s',$sig);
          						  	
			$stmt->execute();	
			
			return $stmt;	
		}
		catch(PDOException $e)
		{
			echo $e->getMessage();
		}				
	}	
	public function redir_sala($url)
	{
		header("Location: $url");
	}
	
}
?>