<?php
    require_once("../../config/token.php");
	require_once("../../models/modules.php");
	
require_once('../handler/class.led.php');
$led = new LED();

if(isset($_POST['led']))
{  
    $itname = strip_tags($_POST['item']);
	$cat = strip_tags($_POST['cat']);
	$cost = strip_tags($_POST['cost']);
	$quant = strip_tags($_POST['quant']);	
	$bought = strip_tags($_POST['bought']);
	$date = strip_tags($_POST['dd']);
	$serial = strip_tags($_POST['serial']);
	
	if($itname=="")	{
		$error[] = "Please provide item name !";	
	}
	if($cat=="Select Category")	{
		$error[] = "Please select item category!";	
	}
	else if($cost=="")	{
		$error[] = "Please provide item cost !";
	}
	else if($quant=="")	{
		$error[] = "Please provide item quantity !";	
	}
	else if($bought=="")	{
		$error[] = "Please provide who bought the item name!";
	}
	else if($date=="")	{
		$error[] = "Please provide item bought date !";
	}
	
	else{
	           $q = $quant * $cost;				 
	          if($led->led($itname,$cat,$cost,$quant,$q,$bought,$date,$serial)){	
             $led->redir_led('../index/ledger.php?recorded');
			 }
	 }
	 }
			
?>