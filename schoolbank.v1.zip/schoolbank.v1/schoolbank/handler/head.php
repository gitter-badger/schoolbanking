<?php
    require_once("../../config/token.php");
	require_once("../../models/modules.php");
	
require_once('../handler/class.app.php');
$user = new APPLICATION();

if(isset($_POST['enter']))
{  
	$fname = strip_tags($_POST['fname']);
	$address = strip_tags($_POST['haddress']);	
	$phone = strip_tags($_POST['phone']);
	$employment_date = strip_tags($_POST['date']);
	$department = strip_tags($_POST['department']);	
	$qualification = strip_tags($_POST['qualification']);	
	$file_no = strip_tags($_POST['fileno']);
	$designation = strip_tags($_POST['desc']);
	
	if($fname=="")	{
		$error[] = "Please provide Staff Name !";	
	}
	else if($address=="")	{
		$error[] = "Please provide Staff Home Address !";	
	}
	else if($phone=="")	{
		$error[] = "Please provide Staff Phone Number !";
	}
	else if($employment_date=="")	{
		$error[] = "Please provide Staff employment Date !";	
	}
	else if($department=="")	{
		$error[] = "Please provide Staff Department !";
	}
	else if($qualification=="")	{
		$error[] = "Please provide Staff Qualification !";
	}
	else if($file_no=="")	{
		$error[] = "Please provide Staff File Number !";	
	}
	else if($designation=="")	{
		$error[] = "Please provide Staff Designation !";
	}
	
	else{
		try
		{
			$stmt = $user->runQuery("SELECT fname FROM application WHERE fname=:f ");
			$stmt->execute(array(':f'=>$fname));
			$row=$stmt->fetch(PDO::FETCH_ASSOC);
				
			if($row['fname']==$fname) {
				$error[] = "Sorry Staff with this name is already Registered !";
				 exit;
			}
			else
			{ 
			
			 $file1 = rand(1000,100000)."-".$_FILES['documents']['name'];
    $file_loc1 = $_FILES['documents']['tmp_name'];
 $file_size1 = $_FILES['documents']['size'];
 $file_type1 = $_FILES['documents']['type'];
 $folder1 ="../handler/docs/";
 
 // new file size in KB
 $new_size1 = $file_size1/1024;  
 // new file size in KB
 
 // make file name in lower case
 $new_file_name1 = strtolower($file1);
 // make file name in lower case
 
 $documents=str_replace(' ','-',$new_file_name1);
  move_uploaded_file($file_loc1,$folder1.$documents);
		
	 $file = rand(1000,100000)."-".$_FILES['passport']['name'];
    $file_loc = $_FILES['passport']['tmp_name'];
 $file_size = $_FILES['passport']['size'];
 $file_type = $_FILES['passport']['type'];
 $folder="../handler/staff/";
 
 // new file size in KB
 $new_size = $file_size/1024;  
 // new file size in KB
 
 // make file name in lower case
 $new_file_name = strtolower($file);
 // make file name in lower case
 
 $passport=str_replace(' ','-',$new_file_name);
  move_uploaded_file($file_loc,$folder.$passport);
 if($documents=="")	{
		$error[] = "Please select Staff Documents !";
	}
	else if($passport=="")	{
		$error[] = "Please select Staff Passport !";	
	} 
	else{
	         if($user->apply($fname,$address,$phone,$employment_date,$department,$qualification,$file_no,$designation,$documents,$passport)){	

 include_once('../modules/u/fpdf/fpdf.php');

require('../modules/table.php');

function Footer()
{
$this->SetY(-15);
$this->SetFont('Arial','I',8);
$this->Cell(0,10,''.$this->PageNo().'/{nb}',0,0,'C');
}
function ChapterTitle($num, $label)
{
$this->SetFont('Arial','',12);
$this->SetFillColor(200,220,255);
$this->Cell(0,6,"$num $label",0,1,'L',true);
$this->Ln(0);
}
function ChapterTitle2($num, $label)
{
$this->SetFont('Arial','',12);
$this->SetFillColor(249,249,249);
$this->Cell(0,1,"$num $label",0,1,'L',true);
$this->Ln(0);
}
$pdf = new PDF();
$pdf->AliasNbPages();
$pdf->AddPage();
$pdf->SetFont('Times','',12);
$pdf->SetTextColor(100,50,100);
$logo = "../modules/image/logo.jpg";
$pdf->Image($logo,90,17,20);
$pdf->SetFont('Arial','B',18);
$pdf->Ln(1);
$pdf->Cell(180,5,'Emerald British Nur/Pry School',0,1,'C');

$pdf->Ln(24);
$pdf->SetTextColor(139,0,0);
$pdf->SetFont('Arial','',14);
$pdf->Cell(180,5,'School Address',0,1,'C');
$pdf->Ln(2);
$pdf->Cell(180,5,'TEL: 08164649834',0,1,'C');
$pdf->Ln(2);
$pdf->SetFont('Arial','',9);
$pdf->Cell(180,5,'Website: www.e-emerald.org',0,1,'C');
$pdf->Ln(3);
$pdf->Cell(0,0,0,1,'C');
$pdf->Ln(5);
$pdf->SetTextColor(100,50,100);
$pdf->SetFont('Arial','B',12);
$pdf->Cell(180,5,'STAFF APPLICATION BOOKLET',0,1,'C');
$pdf->Ln(6);
$pdf->SetFont('Times','',12);
$pdf->Cell(180,5,'Name:-------------------------------------------------' .$fname,0,1,'L');
$pdf->Ln(2);
$pdf->Cell(180,5,'Address:----------------------------------------------' .$address,0,1,'L');
$pdf->Ln(2);
$pdf->Cell(180,5,'Phone:-------------------------------------------------' .$phone,0,1,'L');
$pdf->Ln(2);
$pdf->Cell(180,5,'Employment Date:-----------------------------------' .$employment_date,0,1,'L');
$pdf->Ln(2);
$pdf->Cell(180,5,'Department:-------------------------------------------' .$department,0,1,'L');
$pdf->Ln(2);
$pdf->Cell(180,5,'Qualification:----------------------------------------- ' .$qualification,0,1,'L');
$pdf->Ln(2);
$pdf->Cell(180,5,'File NO:------------------------------------------------' .$file_no,0,1,'L');
$pdf->Ln(2);
$pdf->Cell(180,5,'Designation:------------------------------------------- ' .$designation,0,1,'L');
$pdf->Ln(120);
$pdf->Cell(180,5,'* For more informations or complaints contact the school management.',0,1,'C');
$pdf->Ln(1);
$pdf->SetTextColor(105,105,105);
$pdf->SetFont('Arial','',7);
$pdf->Cell(180,5,'Printed from Emerald British Nur/Pry School Inventory Software',0,1,'C');
$pdf->Ln(2);
$pdf->SetFont('Times','',7);
$pdf->Ln(2);
$pdf->Image($folder.$passport,160,70,50);
$pdf->Cell(0,0,'',0,1,'R');
$filename="staff-application.pdf";
$pdf->Output($filename,'I');

				}
			}
		}
		}
		catch(PDOException $e)
		{
			echo $e->getMessage();
		}
	}	
}

?>