<?php

require_once('config.php');

class LAPS
{	
private $conn;
	public function __construct()
	{
		$database = new Database();
		$db = $database->dbConnection();
		$this->conn = $db;
    }
	
	public function runQuery($sql)
	{
		$stmt = $this->conn->prepare($sql);
		return $stmt;
	}
	
	public function laps($trans,$fname,$date2,$amt_ob,$amt_paid,$ret_to,$rsig,$date,$debt,$status)
	{
		try
		{
			
			$stmt = $this->conn->prepare("INSERT INTO loan_paid(trans_id,fname,date2,amount_of_loan_obtained,amount_paid,loan_returned,sign_of_receiving_officer,date,debt_owed,status) 
		                                               VALUES(:tn, :fn, :d2, :am, :amp, :lo, :sigo, :ddd, :deb, :st)");
			$stmt->bindparam(':tn',$trans);	
			$stmt->bindparam(':fn',$fname);
			$stmt->bindparam(':d2',$date2);
                $stmt->bindparam(':am',$amt_ob);
			$stmt->bindparam(':amp',$amt_paid);
			$stmt->bindparam(':lo',$ret_to);
			$stmt->bindparam(':sigo',$rsig);
			$stmt->bindparam(':ddd',$date);
			$stmt->bindparam(':deb',$debt);
			$stmt->bindparam(':st',$status);
          						  	
			$stmt->execute();	
			
			return $stmt;	
		}
		catch(PDOException $e)
		{
			echo $e->getMessage();
		}				
	}	
	public function redir_laps($url)
	{
		header("Location: $url");
	}
	
}
?>