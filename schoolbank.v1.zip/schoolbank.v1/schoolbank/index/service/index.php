<?php
require_once('../../../libraries/barcode/drawer/home.php');
 require_once("../../../config/token.php");
require_once("../../../models/modules.php");
require_once('../../handler/class.pupils.php');
$p = new PUPILS();

if(isset($_GET['id'])){
$id = $_GET['id'];
          $stmt = $p->runQuery("SELECT * FROM service_provider WHERE app_id=:ap");
	      $stmt->execute(array(":ap"=>$id));
	      $userRow=$stmt->fetch(PDO::FETCH_ASSOC);
		  }else{
		  
		 
		  }

?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8" />
    <title>Emerald Service Provided Booklet</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />

    <link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.min.css" />
    <link rel="stylesheet" type="text/css" href="font-awesome/css/font-awesome.min.css" />

    <script type="text/javascript" src="js/jquery-1.10.2.min.js"></script>
    <script type="text/javascript" src="bootstrap/js/bootstrap.min.js"></script>
	<script src="../script.js"></script>
		<script src="../../jquery-1.11.3-jquery.min.js"></script>
<script src="../../dist/js/loading.js"></script>
<link href="../../dist/css/loading.css" rel="stylesheet">
</head>
<body>
<div class="loader"></div>
<div class="container">

<div class="page-header">
    <h1><?php echo $mano["invoice"] ?><span style="float:right;"><img src="../../img/header_logo.png" width="50" height="50"></span></h1>
</div>

<!-- Simple Invoice - START -->
<div class="container">
    <div class="row">
        <div class="col-xs-12">
            <div class="text-center">
                <i class="fa fa-search-plus pull-left icon"></i>
                <h2><?php echo $mano["inv"] ?> <?php echo $userRow["sname"] ?></h2>
            </div>
            <hr><br><br>
        </div>
    </div>
    <div class="row">
        <div class="col-md-12">
            <div class="panel panel-default">
                <div class="panel-heading">
                    <h3 class="text-center"><strong><?php echo $mano["service"] ?></strong></h3>
                </div>
                <div class="panel-body">
                    <div class="table-responsive">
                        <table class="table table-condensed">
                            <thead>
                                
                                    <td><strong>Service ID</strong></td>
									<td class="text-center"><strong><?php echo $mano["spro"] ?></strong></td>
                                    <td class="text-center"><strong><?php echo $mano["date"] ?></strong></td>
                                    <td class="text-center"><strong><?php echo $mano["session"] ?></strong></td>
                                    <td class="text-right"><strong><?php echo $mano["amc"] ?></strong></td>
									
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td><?php echo $userRow["app_id"] ?></td>
									 <td class="text-center"><?php echo $userRow["serp"] ?></td>
                                    <td class="text-center"><?php echo $userRow["date"] ?></td>
                                    <td class="text-center"><?php echo $userRow["session"] ?></td>
                                    <td class="text-right">NGN<?php echo $userRow["amc"] ?></td>
                                </tr>
                               
                               
                                <tr>
                                    <td class="highrow"></td>
                                    <td class="highrow"></td>
                                    <td class="highrow text-center"><strong>Subtotal</strong></td>
                                    <td class="highrow text-right"></td>
                                </tr>
								<tr>
                                    <td class="emptyrow"></td>
                                    <td class="emptyrow"></td>
                                    <td class="emptyrow text-center"><strong>Amount Paid</strong></td>
                                    <td class="emptyrow text-right">NGN<?php echo $userRow["amp"] ?></td>
                                </tr>
								<tr>
                                    <td class="emptyrow"></td>
                                    <td class="emptyrow"></td>
                                    <td class="emptyrow text-center"><strong>Balance</strong></td>
                                    <td class="emptyrow text-right">NGN<?php echo $userRow["balance"] ?></td>
                                </tr>
                              
                                <tr>
                                    <td class="emptyrow"><i class="fa fa-barcode iconbig"></i></td>
                                    <td class="emptyrow"></td>
                                </tr>
								<tr>
                                    <td class="emptyrow"><?php echo $mano['rights'] ?></td>
                                    <td class="emptyrow"></td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
.height {
    min-height: 200px;
}

.icon {
    font-size: 47px;
    color: #5CB85C;
}

.iconbig {
    font-size: 77px;
    color: #5CB85C;
}

.table > tbody > tr > .emptyrow {
    border-top: none;
}

.table > thead > tr > .emptyrow {
    border-bottom: none;
}

.table > tbody > tr > .highrow {
    border-top: 3px solid;
}
</style>

<!-- Simple Invoice - END -->

</div>

</body>
</html>