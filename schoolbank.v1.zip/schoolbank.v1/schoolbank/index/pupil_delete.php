<?php
session_start();
    require_once("../../config/token.php");
	require_once("../../models/modules.php");
	
require_once('../handler/class.pupils.php');
$del = new PUPILS();

         if(isset($_GET['id'])){
		
	     $id = $_GET['id'];
		
		 
	     $stmt = $del->runQuery("DELETE FROM pupils WHERE app_id=:id");
	      $stmt->execute(array(":id"=>$id));
		  
		  if($stmt){
		   $del->redir_pup('../index/pupils.php?yes='.$id.'');
		   }
		   }
		   ?>
		  