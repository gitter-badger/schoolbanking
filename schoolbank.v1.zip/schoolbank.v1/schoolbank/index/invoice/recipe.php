<?php
require_once('../../../libraries/barcode/drawer/home.php');
 require_once("../../../config/token.php");
require_once("../../../models/modules.php");
require_once('../../handler/class.user.php');
$l = new MANOSOFT();

if(isset($_GET['idr'])){
$in = $_GET['idr'];
          $stmt = $l->runQuery("SELECT * FROM users WHERE trans_id=:rrr");
	      $stmt->execute(array(":rrr"=>$in));
	      $r=$stmt->fetch(PDO::FETCH_ASSOC);
		  }else{
		   $l->redirect('payment.php');
		   }
		  
?>
<!doctype html>
<html>
	<head>
		<meta charset="utf-8">
		<title><?php echo $r['paying_for'] ?>  Payment Receipt Booklet</title>
		<link rel="stylesheet" href="style.css">
		<link rel="license" href="http://www.manomite.net">
		<script src="script.js"></script>
		<script src="../script.js"></script>
		<script src="../../jquery-1.11.3-jquery.min.js"></script>
<script src="../../dist/js/loading.js"></script>
<link href="../../dist/css/loading.css" rel="stylesheet">
	</head>
	<body>
	 <div class="loader"></div>
		<header>
			<h1><?php echo $mano["invoice"] ?></h1>
			<address>
				<p><?php echo $mano["name10"] ?></p>
				<p><?php echo $mano["address"] ?></p>
				<p><?php echo $mano["tel"] ?></p>
			</address>
			<span><img alt="" src="../../img/header_logo.png" width="60" height="60"></span>
		</header>
		<article>
			<h1>Recipient</h1>
			<address>
				<p><?php echo $r['paying_for'] ?> Payment Receipt Booklet</p>
			</address>
			<table class="meta">
				<tr>
					<th><?php echo $mano['app_id'] ?></th>
					<td><?php echo $r['trans_id'] ?></td>
				</tr>
				<tr>
					<th><?php echo $mano['date'] ?></th>
					<td><?php echo $r['date_payed'] ?></td>
				</tr>
				<tr>
					<th><span><?php echo $mano['amt2'] ?></span></th>
					<td><span id="prefix">NGN</span><span><?php echo $r['amount_paid'] ?></span></td>
				</tr>
			</table>
			<table class="inventory">
				<thead>
					<tr>
						<th><?php echo $mano['pupil'] ?></th>
						<th><?php echo $mano['des'] ?></th>
						<th><?php echo $mano['required'] ?></th>
						<th><?php echo $mano['status'] ?></th>
					</tr>
				</thead>
				<tbody>
					<tr>
						<td><a class="cut">-</a><?php echo $r['paying_for'] ?></td>
						<td><?php echo $r['purpose'] ?></td>
						<td>NGN<?php echo $r['actual_amount'] ?></td>
						<td><?php echo $r['status'] ?></td>
					</tr>
				</tbody>
			</table>
			<a class="add">+</a>
			<table class="balance">
				<tr>
					<th><span>Amount Paid</span></th>
					<td>NGN<?php echo $r['amount_paid'] ?></td>
				</tr>
				<tr>
					<th><?php echo $mano['balance'] ?></th>
					<td>NGN <?php echo $r['dept'] ?></td>
				</tr>
				<tr>
					<th><?php echo $mano['receiver2'] ?></th>
					<td></td>
				</tr>
			</table>
		</article>
		<aside>
			<h1><span><?php echo $mano['copy'] ?></span></h1>
			<div>
				<p><?php echo $mano['rights'] ?></p>
			</div>
		</aside>
	</body>
</html>