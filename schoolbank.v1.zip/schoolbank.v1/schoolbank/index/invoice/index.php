<?php
require_once('../../../libraries/barcode/drawer/home.php');
 require_once("../../../config/token.php");
require_once("../../../models/modules.php");
require_once('../../handler/class.laps.php');
$laps = new LAPS();

if(isset($_GET['inv'])){
$inv = $_GET['inv'];

          $stmt = $laps->runQuery("SELECT * FROM loan WHERE trans_id=:ffff");
	      $stmt->execute(array(":ffff"=>$inv));
	      $userRow=$stmt->fetch(PDO::FETCH_ASSOC);
		  }else{
		  
		 
		  }

?>
<!doctype html>
<html>
	<head>
		<meta charset="utf-8">
		<title><?php echo $userRow['fname'] ?> Loan Invoice</title>
		<link rel="stylesheet" href="style.css">
		<link rel="license" href="http://www.manomite.net">
		<script src="../script.js"></script>
		<script src="../../jquery-1.11.3-jquery.min.js"></script>
<script src="../../dist/js/loading.js"></script>
<link href="../../dist/css/loading.css" rel="stylesheet">
	</head>
	<body>
	 <div class="loader"></div>
		<header>
			<h1><?php echo $mano["invoice"] ?></h1>
			<address>
				<p><?php echo $mano["name5"] ?></p>
				<p><?php echo $mano["address"] ?></p>
				<p><?php echo $mano["tel"] ?></p>
			</address>
			<span><img alt="" src="../../img/header_logo.png" width="60" height="60"></span>
		</header>
		<article>
			<h1>Recipient</h1>
			<address>
				<p><?php echo $userRow['fname'] ?> Loan Booklet</p>
			</address>
			<table class="meta">
				<tr>
					<th><?php echo $mano['loan_id'] ?></th>
					<td><?php echo $userRow['trans_id'] ?></td>
				</tr>
				<tr>
					<th><?php echo $mano['date'] ?></th>
					<td><?php echo $userRow['date1'] ?></td>
				</tr>
				<tr>
					<th><span><?php echo $mano['amt'] ?></span></th>
					<td><span id="prefix">#</span><span><?php echo $userRow['amount'] ?></span></td>
				</tr>
			</table>
			<table class="inventory">
				<thead>
					<tr>
						<th><?php echo $mano['name2'] ?></th>
						<th><?php echo $mano['desc'] ?></th>
						<th><?php echo $mano['receiver'] ?></th>
						<th><?php echo $mano['author'] ?></th>
						<th><?php echo $mano['status'] ?></th>
					</tr>
				</thead>
				<tbody>
					<tr>
						<td><a class="cut">-</a><?php echo $userRow['fname'] ?></td>
						<td><?php echo $mano['desc2'] ?></td>
						<td><?php echo $userRow['sign_of_the_receiver'] ?></td>
						<td><?php echo $userRow['loan_authorized'] ?></td>
						<td><?php echo $userRow['status'] ?></td>
					</tr>
				</tbody>
			</table>
			<a class="add">+</a>
			<table class="balance">
				<tr>
					<th><span>Total</span></th>
					<td>#<?php echo $userRow['amount'] ?></td>
				</tr>
				<tr>
					<th><?php echo $mano['author'] ?></th>
					<td></td>
				</tr>
				<tr>
					<th><?php echo $mano['receiver'] ?></th>
					<td></td>
				</tr>
			</table>
		</article>
		<aside>
			<h1><span><?php echo $mano['copy'] ?></span></h1>
			<div>
				<p><?php echo $mano['rights'] ?></p>
			</div>
		</aside>
	</body>
</html>