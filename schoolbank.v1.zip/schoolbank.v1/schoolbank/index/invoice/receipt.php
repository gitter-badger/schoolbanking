<?php
require_once('../../../libraries/barcode/drawer/home.php');
 require_once("../../../config/token.php");
require_once("../../../models/modules.php");
require_once('../../handler/class.laps.php');
$laps = new LAPS();

if(isset($_GET['invo'])){
$invo = $_GET['invo'];
          $stmt = $laps->runQuery("SELECT * FROM loan_paid WHERE trans_id=:rr");
	      $stmt->execute(array(":rr"=>$invo));
	      $use=$stmt->fetch(PDO::FETCH_ASSOC);
		  
		   $stmt2 = $laps->runQuery("SELECT * FROM loan WHERE trans_id=:rr");
	      $stmt2->execute(array(":rr"=>$invo));
	      $user=$stmt2->fetch(PDO::FETCH_ASSOC);
		  }else{
		  
		 
		  }

?>
<!doctype html>
<html>
	<head>
		<meta charset="utf-8">
		<title><?php echo $use['fname'] ?> Loan Payment Receipt Booklet</title>
		<link rel="stylesheet" href="style.css">
		<link rel="license" href="http://www.manosoft.org">
		<script src="script.js"></script>
		<script src="../script.js"></script>
		<script src="../../jquery-1.11.3-jquery.min.js"></script>
<script src="../../dist/js/loading.js"></script>
<link href="../../dist/css/loading.css" rel="stylesheet">
	</head>
	<body>
	 <div class="loader"></div>
		<header>
			<h1><?php echo $mano["invoice"] ?></h1>
			<address>
				<p><?php echo $mano["name5"] ?></p>
				<p><?php echo $mano["address"] ?></p>
				<p><?php echo $mano["tel"] ?></p>
			</address>
			<span><img alt="" src="../../img/header_logo.png" width="60" height="60"></span>
		</header>
		<article>
			<h1>Recipient</h1>
			<address>
				<p><?php echo $use['fname'] ?> Loan Payment Receipt Booklet</p>
			</address>
			<table class="meta">
				<tr>
					<th><?php echo $mano['loan_id'] ?></th>
					<td><?php echo $use['trans_id'] ?></td>
				</tr>
				<tr>
					<th><?php echo $mano['date'] ?></th>
					<td><?php echo $use['date2'] ?></td>
				</tr>
				<tr>
					<th><span><?php echo $mano['amt'] ?></span></th>
					<td><span id="prefix">#</span><span><?php echo $use['amount_of_loan_obtained'] ?></span></td>
				</tr>
			</table>
			<table class="inventory">
				<thead>
					<tr>
						<th><?php echo $mano['name2'] ?></th>
						<th><?php echo $mano['desc'] ?></th>
						<th><?php echo $mano['receiver'] ?></th>
						<th><?php echo $mano['status'] ?></th>
					</tr>
				</thead>
				<tbody>
					<tr>
						<td><a class="cut">-</a><?php echo $use['fname'] ?></td>
						<td><?php echo $mano['desc2'] ?></td>
						<td><?php echo $use['sign_of_receiving_officer'] ?></td>
						<td><?php echo $use['status'] ?></td>
					</tr>
				</tbody>
			</table>
			<a class="add">+</a>
			<table class="balance">
				<tr>
					<th><span>Amount Paid</span></th>
					<td>#<?php echo $use['amount_paid'] ?></td>
				</tr>
				<tr>
					<th><?php echo $mano['balance'] ?></th>
					<td>NGN <?php echo $use['amount_of_loan_obtained'] - $use['amount_paid'] ?></td>
				</tr>
				<tr>
					<th><?php echo $mano['receiver'] ?></th>
					<td></td>
				</tr>
			</table>
		</article>
		<aside>
			<h1><span><?php echo $mano['copy'] ?></span></h1>
			<div>
				<p><?php echo $mano['rights'] ?></p>
			</div>
		</aside>
	</body>
</html>