<?php
session_start();
    require_once("../../config/token.php");
	require_once("../../models/modules.php");
	
require_once('../handler/class.laps.php');
$laps = new LAPS();

         if(isset($_GET['delete'])){
		
	     $id = $_GET['delete'];
		 
		  $stmt = $laps->runQuery("SELECT * FROM application WHERE staff_id=:sd");
	      $stmt->execute(array(":sd"=>$id));
	      $row=$stmt->fetch(PDO::FETCH_ASSOC);
		 $fname =  $row['fname'];
		 
	     $stmt2 = $laps->runQuery("DELETE FROM application WHERE staff_id=:id");
	      $stmt2->execute(array(":id"=>$id));
		  
		   $stmt3 = $laps->runQuery("DELETE FROM loan WHERE fname=:ide");
	      $stmt3->execute(array(":ide"=>$fname));
		  
		   $stmt4 = $laps->runQuery("DELETE FROM loan_paid WHERE fname=:ide");
	      $stmt4->execute(array(":ide"=>$fname));
		  
		   $stmt4 = $laps->runQuery("DELETE FROM salary WHERE fname=:ide");
	       $stmt4->execute(array(":ide"=>$fname));
		  
		  if($stmt && $stmt2 && $stmt3 && $stmt4){
		   $laps->redir_laps('profile.php?yes=1');
		   }
		   }
		   ?>
		  