<?php
    session_start();
    require_once("../../config/token.php");
	require_once("../handler/session.php");
	require_once("../../models/modules.php");
	
require_once('../handler/class.user.php');
$user = new MANOSOFT();

if(isset($_POST['apply']))
{  

    function manosoft_token($len = 10){
	$tok = '';
	$chars = array_merge(range('A','Z'),range('a','z'),range('0','9'));
	$max = count($chars) - 1;
	for($i = 0; $i<$len; $i++){
	$tcp = mt_rand(0, $max);
	$tok .= $chars[$tcp];
	}
	return $tok;
	}
	$teller_id = strip_tags($_POST['teller_no']);
	$trans_id = manosoft_token();
	$amount_paid = strip_tags($_POST['amp']);	
	$actual_amount = strip_tags($_POST['acm']);
	$purpose = strip_tags($_POST['p']);
	$depositor_name = strip_tags($_POST['dname']);	
	$depositor_phone = strip_tags($_POST['dphone']);	
	$depositor_address = strip_tags($_POST['dad']);
	$paying_for = strip_tags($_POST['pf']);
	$session = strip_tags($_POST['ses']);	
	$class = strip_tags($_POST['class']);	
	$date_payed = strip_tags($_POST['dp']);
	$cal = $actual_amount-$amount_paid;
	$total = $amount_paid;
	$dept = $cal;
	if($dept == 0){
	$status = 'completed payments';
	}else{
	$status = 'incomplete payments';
	}

	$token = manosoft_token();			
	
	if($teller_id=="")	{
		$error[] = "Please provide teller ID !";	
	}
	else if($trans_id=="")	{
		$error[] = "Error generating transaction ID. Please contact Manosoft. !";	
	}
	else if($amount_paid=="")	{
		$error[] = "Please provide Amount Paid !";
	}
	else if($actual_amount=="")	{
		$error[] = "Please provide Actual Amount/Required Amount !";	
	}
	else if($purpose=="")	{
		$error[] = "Please provide Purpose of Payment !";
	}
	else if($depositor_name=="")	{
		$error[] = "Please provide depositor name !";
	}
	else if($depositor_phone=="")	{
		$error[] = "Please provide depositor phone !";	
	}
	else if($paying_for=="")	{
		$error[] = "Please provide Student Paying for !";
	}
	else if($session=="")	{
		$error[] = "Please select session !";
	}
	else if($class=="")	{
		$error[] = "Please select class !";	
	}
	else if($date_payed=="")	{
		$error[] = "Please provide date payed !";
	}
	else
	{
	 $file = rand(1000,100000)."-".$_FILES['teller_file']['name'];
    $file_loc = $_FILES['teller_file']['tmp_name'];
 $file_size = $_FILES['teller_file']['size'];
 $file_type = $_FILES['teller_file']['type'];
 $folder="../handler/upload/";
 
 // new file size in KB
 $new_size = $file_size/1024;  
 // new file size in KB
 
 // make file name in lower case
 $new_file_name = strtolower($file);
 // make file name in lower case
 
 $teller_file=str_replace(' ','-',$new_file_name);
  move_uploaded_file($file_loc,$folder.$teller_file);
		try
		{
			$stmt = $user->runQuery("SELECT teller_id, trans_id FROM users WHERE teller_id=:tid OR trans_id=:trid");
			$stmt->execute(array(':tid'=>$teller_id, ':trid'=>$trans_id));
			$row=$stmt->fetch(PDO::FETCH_ASSOC);
				
			if($row['teller_id']==$teller_id) {
				$error[] = "Sorry Teller Number Registered !";
			}
			else if($row['trans_id']==$trans_id) {
				$error[] = "Sorry Transaction ID Registered !";
			}
			else
			{  
			$_SESSION['teller_id'] = $teller_id;  
	         if($user->register($teller_id,$trans_id,$amount_paid,$actual_amount,$purpose,$depositor_name,$depositor_phone,$depositor_address,$paying_for,$session,$class,$date_payed,$teller_file,$total,$dept,$token,$status)){	
			
	$stmt = $user->runQuery("SELECT * FROM users WHERE teller_id=:id");
	$stmt->execute(array(":id"=>$_SESSION['teller_id']));
	$userRow=$stmt->fetch(PDO::FETCH_ASSOC);
	$teller_token = $userRow['id'];
	 $_SESSION['token'] = $teller_token;
	 if($_SESSION['token'] != ""){
					$user->redirect('receipts.php');
					}else{
					$error[] = "Session not set";
					}
				}
			}
		}
		catch(PDOException $e)
		{
			echo $e->getMessage();
		}
	}	
}
?>