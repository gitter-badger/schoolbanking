<?php
require_once('../../libraries/barcode/drawer/home.php');
    require_once("../../config/token.php");
	require_once("../handler/session.php");
	require_once("../../models/modules.php");
?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title><?php echo $mano["cname"] ?></title>
<script src="../jquery-1.11.3-jquery.min.js"></script>
<script src="../dist/js/loading.js"></script>
<link href="../dist/css/loading.css" rel="stylesheet">
<link href='//fonts.googleapis.com/css?family=Orbitron:500' rel='stylesheet' type='text/css'>
<link href="css/style.css" rel="stylesheet" type="text/css" media="all" />
    <!-- Bootstrap Core CSS -->
    <link href="../vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- MetisMenu CSS -->
    <link href="../vendor/metisMenu/metisMenu.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="../dist/css/sb-admin-2.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="../vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>

<body>
 <div class="loader"></div>
    <div id="wrapper">

        <!-- Navigation -->
        <nav class="navbar navbar-default navbar-static-top" role="navigation" style="margin-bottom: 0">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
              <a class="navbar-brand" href="index.php"><span style="color:#000033; font-size:32px;"><img src="../img/header_logo.png" width="30" height="30"> <?php echo $mano['cname'] ?></span></a>
            </div>
            <!-- /.navbar-header -->

           <ul class="nav navbar-top-links navbar-right">
                <li class="dropdown">
                    <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                        <i class="fa fa-envelope fa-fw"></i> <i class="fa fa-caret-down"></i>
                    </a>
                    <ul class="dropdown-menu dropdown-messages">
                        <li>
                            <a href="#">
                                <div>
                                    <strong><?php echo $mano["welcome"] ?> </strong>
                                    <span class="pull-right text-muted">
                                        <em><?php echo $time; ?></em>
                                    </span>
                                </div>
                                <div><?php echo $mano["keys"] ?> </div>
                            </a>
                        </li>
                        <li class="divider"></li>
                    </ul>
                    <!-- /.dropdown-messages -->
                </li>
                <!-- /.dropdown -->
                <li class="dropdown">
                    <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                        <i class="fa fa-tasks fa-fw"></i> <i class="fa fa-caret-down"></i>
                    </a>
                    <ul class="dropdown-menu dropdown-tasks">
                        <li>
                            <a href="#">
                                <div>
                                   <p>
                                        <strong>System Structure</strong>
                                        <span class="pull-right text-muted"><?php echo $mano["percentage"] ?>%</span>
                                    </p>
                                    <div class="progress progress-striped active">
                                        <div class="progress-bar progress-bar-success" role="progressbar" aria-valuenow="40" aria-valuemin="0" aria-valuemax="100" style="width: <?php echo $mano['percentage']; ?>">
                                            <span class="sr-only"><?php echo $mano["percentage"] ?>% Complete (success)</span>
                                        </div>
                                    </div>
                                </div>
                            </a>
                        </li>
                        <li class="divider"></li>
                    </ul>
                    <!-- /.dropdown-tasks -->
                </li>
                <!-- /.dropdown -->
               
                <!-- /.dropdown -->
                <li class="dropdown">
                    <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                        <i class="fa fa-user fa-fw"></i> <i class="fa fa-caret-down"></i>
                    </a>
                    <ul class="dropdown-menu dropdown-user">
                        <li><a href="#"><i class="fa fa-user fa-fw"></i><?php echo $auth_row["user_name"] ?> Account</a>
                        </li>
                        <li class="divider"></li>
                        <li><a href="../handler/logout.php"><i class="fa fa-sign-out fa-fw"></i> Logout</a>
                        </li>
                    </ul>
                    <!-- /.dropdown-user -->
                </li>
                <!-- /.dropdown -->
            </ul>
            <!-- /.navbar-top-links -->

           <div class="navbar-default sidebar" role="navigation">
                <div class="sidebar-nav navbar-collapse">
                    <ul class="nav" id="side-menu">
                        <li class="sidebar-search">
                            <form action="" method="post">
							<?php require_once('../handler/file.php'); ?>
							<?php
			if(isset($error))
			{
			 	foreach($error as $error)
			 	{
					 ?>
                     <div class="alert alert-danger">
                        <i class="glyphicon glyphicon-warning-sign"></i> &nbsp; <?php echo $error; ?>
                     </div>
                     <?php
				}
			}
		
			?>
                            <div class="input-group custom-search-form">
                                <input type="text" name="s" class="form-control" placeholder="Search...">
                                <span class="input-group-btn">
                                <button class="btn btn-default" name="search" type="submit">
                                    <i class="fa fa-search"></i>
                                </button>
                            </span>
                            </div>
                                </form>
                            <!-- /input-group -->
                        </li>
                      <li>
                            <a href="index.php"><i class="fa fa-dashboard fa-fw"></i> Navigation</a>
                        </li>
						
						 
						
                        <li>
                            <a href="#"><i class="fa fa-bar-chart-o fa-fw"></i>Teller<span class="fa arrow"></span></a>
                            <ul class="nav nav-second-level">
                                <li>
                                    <a href="payment.php">Enter Payment</a>
                                </li>
								 <li>
                                    <a href="search.php">Fees Report</a>
                                </li>
                                <li>
                                    <a href="instructions.php">Manual</a>
                                </li>
                            </ul>
                            <!-- /.nav-second-level -->
                        </li>
                        <li>
                            <a href="#"><i class="fa fa-bar-chart-o fa-fw"></i>Staff<span class="fa arrow"></span></a>
							
							 <ul class="nav nav-second-level">
                                <li>
                                    <a href="Application.php">Application</a>
                                </li>
                                <li>
                                    <a href="profile.php">Staff Profile</a>
                                </li>
                            </ul>
                        </li>
						
						  <li>
                            <a href="#"><i class="fa fa-bar-chart-o fa-fw"></i>Salary<span class="fa arrow"></span></a>
							 <ul class="nav nav-second-level">
							
                                <li>
                                    <a href="Salary.php">Enter Salary</a>
                                </li>
								 <li>
                                    <a href="loan-collections.php">Loan Collections</a>
                                </li>
								<li>
                                    <a href="loan-acceptance.php">Loan Acceptance</a>
                                </li>
								</ul>
								</li>
							
								 <li>
                            <a href="#"><i class="fa fa-bar-chart-o fa-fw"></i>Pupils<span class="fa arrow"></span></a>
							
							 <ul class="nav nav-second-level">
                                <li>
                                    <a href="pupils.php">Pupils Application</a>
                                </li>
                                <li>
                                    <a href="pupils_report.php">Pupils Report</a>
                                </li>
                            </ul>
                        </li>
							  <li>
                            <a href="#"><i class="fa fa-bar-chart-o fa-fw"></i>Sales<span class="fa arrow"></span></a>
							
							 <ul class="nav nav-second-level">
                                <li>
                                    <a href="sales.php">Enter Sales</a>
                                </li>
                                <li>
                                    <a href="sales_report.php">Sales Report</a>
                                </li>
                            </ul>
                        </li>
                                 <li>
                            <a href="#"><i class="fa fa-bar-chart-o fa-fw"></i>Service Provider<span class="fa arrow"></span></a>
							
							 <ul class="nav nav-second-level">
                                <li>
                                    <a href="service_provider.php">Application</a>
                                </li>
                                <li>
                                    <a href="service_provider_reports.php">Service Provider Reports</a>
                                </li>
                            </ul>
                        </li>
                               
                        <li>
                                    <a href=""><i class="fa fa-bar-chart-o fa-fw"></i>Ledger<span class="fa arrow"></span></a>
									 <ul class="nav nav-second-level">
									 <li>
                                    <a href="ledger.php">Enter Ledger</a>
                                </li>
							
                                <li>
                                    <a href="general.php">General Ledger Details</a>
                                </li>
								<li>
                                    <a href="fixed.php">Fixed Ledger Details</a>
                                </li>
                                <li>
								
                                    <a href="miscellaneous.php">Miscellaneous Ledger Details</a>
                                </li>
                    </ul>
                </div>
                <!-- /.sidebar-collapse -->
            </div>
            <!-- /.navbar-static-side -->
        </nav>

        <div id="page-wrapper">
            <div class="row">

	<div class="header">
		<h1>Staff Profile</h1><br><br><br>
	</div>
	
		<?php
    require_once("../../config/token.php");
	require_once("../../models/modules.php");
	
require_once('../handler/class.led.php');
$led = new LED();

               if(isset($_GET['view'])){
		
	           $v = $_GET['view'];
           $stmt = $led->runQuery("SELECT * FROM application WHERE staff_id=:st");
	      $stmt->execute(array(":st"=>$v));
	       $u=$stmt->fetch(PDO::FETCH_ASSOC);
		   }
		   ?>
			
				<span style="float:right;"> <img src="../handler/staff/<?php echo $u['passport'] ?>" width="100px" height="100px"></span>
			
			
					<h3> <?php echo $u['fname'] ?> Profile</h3>
					<p>STAFF ADDRESS: <?php echo $u['address'] ?></p>
					<p>STAFF PHONE: <?php echo $u['phone'] ?></p>
					<p>STAFF EMPLOYMENT DATE: <?php echo $u['employment_date'] ?></p>
					<p>DEPARTMENT: <?php echo $u['department'] ?></p>
					<p>QUALIFICATION: <?php echo $u['qualification'] ?></p>
					<p>FILE_NO: <?php echo $u['file_no'] ?></p>
					<p>DESIGNATION: <?php echo $u['designation'] ?></p>
					<p>DOCUMENT: <a href=../handler/docs/<?php echo $u['documents'] ?>>View</a></p>
			
                <div class="col-lg-12">
                    <h2 class="page-header">Account</h2>
					  <?php require_once('../handler/view.php');
							  ?><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
          
            <!-- /.row -->
        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->

    <!-- jQuery -->
    <script src="../vendor/jquery/jquery.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="../vendor/bootstrap/js/bootstrap.min.js"></script>

    <!-- Metis Menu Plugin JavaScript -->
    <script src="../vendor/metisMenu/metisMenu.min.js"></script>

    <!-- Custom Theme JavaScript -->
    <script src="../dist/js/sb-admin-2.js"></script>

</body>

</html>
