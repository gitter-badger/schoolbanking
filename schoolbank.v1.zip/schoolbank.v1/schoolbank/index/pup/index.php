<?php
require_once('../../../libraries/barcode/drawer/home.php');
 require_once("../../../config/token.php");
require_once("../../../models/modules.php");
require_once('../../handler/class.pupils.php');
$p = new PUPILS();

if(isset($_GET['id'])){
$id = $_GET['id'];
          $stmt = $p->runQuery("SELECT * FROM pupils WHERE app_id=:ap");
	      $stmt->execute(array(":ap"=>$id));
	      $userRow=$stmt->fetch(PDO::FETCH_ASSOC);
		  }else{
		  
		 
		  }

?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8" />
    <title>Emerald Pupils Application Booklet</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />

    <link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.min.css" />
    <link rel="stylesheet" type="text/css" href="font-awesome/css/font-awesome.min.css" />

    <script type="text/javascript" src="js/jquery-1.10.2.min.js"></script>
    <script type="text/javascript" src="bootstrap/js/bootstrap.min.js"></script>
	<script src="../script.js"></script>
		<script src="../../jquery-1.11.3-jquery.min.js"></script>
<script src="../../dist/js/loading.js"></script>
<link href="../../dist/css/loading.css" rel="stylesheet">
</head>
<body>
 <div class="loader"></div>
<div class="container">

<div class="page-header">
    <h1><?php echo $mano["invoice"] ?><span style="float:right;"><img src="../../img/header_logo.png" width="50" height="50"></span></h1>
</div>

<!-- Simple Invoice - START -->
<div class="container">
    <div class="row">
        <div class="col-xs-12">
            <div class="text-center">
                <i class="fa fa-search-plus pull-left icon"></i>
                <h2><?php echo $mano["inv"] ?> <?php echo $userRow["pupil_name"] ?> <span style="float:right;"><img src="../../handler/pupils/<?php echo $userRow["passport"] ?>" width="70" height="70"></span></h2><b><br> Invoice ID:  <?php echo $userRow["app_id"] ?>
				</b><br>
            </div>
            <hr>
            <div class="row">
                <div class="col-xs-12 col-md-3 col-lg-3 pull-left">
                    <div class="panel panel-default height">
                        <div class="panel-heading"><?php echo $mano["items"] ?></div>
                        <div class="panel-body">
                            <p><?php echo $userRow["description"] ?></p>
                        </div>
                    </div>
                </div>
                <div class="col-xs-12 col-md-3 col-lg-3">
                    <div class="panel panel-default height">
                        <div class="panel-heading"><?php echo $mano["fees"] ?></div>
                        <div class="panel-body">
                            <strong>School Fees:</strong> NGN<?php echo $userRow["fees"] ?><br>
                            <strong>Items Total Fees:</strong> NGN<?php echo $userRow["total"] ?><br>
                            <strong>Final Total:</strong> NGN<?php echo $userRow["final"] ?><br>
                        </div>
                    </div>
                </div>
                <div class="col-xs-12 col-md-3 col-lg-3">
                    <div class="panel panel-default height">
                        <div class="panel-heading"><?php echo $mano["pay"] ?></div>
                        <div class="panel-body">
                            <strong>Bank Name:</strong> <?php echo $mano["bname"] ?><br>
                            <strong>Account Name:</strong> <?php echo $mano["aname"] ?><br>
                            <strong>Account NO:</strong> <?php echo $mano["acc"] ?><br>
                          
                        </div>
                    </div>
                </div>
                <div class="col-xs-12 col-md-3 col-lg-3 pull-right">
                    <div class="panel panel-default height">
                        <div class="panel-heading"><?php echo $mano["details"] ?></div>
                        <div class="panel-body">
                            <strong>Pupil Name:</strong> <?php echo $userRow["pupil_name"] ?><br>
                           
                            <strong>Pupil Class:</strong> <?php echo $userRow["class"] ?><br>
							 <strong>Session:</strong> <?php echo $userRow["session"] ?><br>
                            <strong>Invoice Date:</strong> <?php echo $userRow["date"] ?><br>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-md-12">
            <div class="panel panel-default">
                <div class="panel-heading">
                    <h3 class="text-center"><strong><?php echo $mano["ff"] ?></strong></h3>
                </div>
                <div class="panel-body">
                    <div class="table-responsive">
                        <table class="table table-condensed">
                            <thead>
                                <tr>
                                    <td><strong><?php echo $mano["items"] ?></strong></td>
                                    <td class="text-center"><strong><?php echo $mano["schfees"] ?></strong></td>
                                    <td class="text-center"><strong><?php echo $mano["itemf"] ?></strong></td>
                                    <td class="text-right"><strong><?php echo $mano["totall"] ?></strong></td>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td><?php echo $userRow["description"] ?></td>
                                    <td class="text-center">NGN<?php echo $userRow["fees"] ?></td>
                                    <td class="text-center">NGN<?php echo $userRow["total"] ?></td>
                                    <td class="text-right">NGN<?php echo $userRow["final"] ?></td>
                                </tr>
                               
                               
                                <tr>
                                    <td class="highrow"></td>
                                    <td class="highrow"></td>
                                    <td class="highrow text-center"><strong>Subtotal</strong></td>
                                    <td class="highrow text-right">NGN<?php echo $userRow["final"] ?></td>
                                </tr>
                              
                                <tr>
                                    <td class="emptyrow"><i class="fa fa-barcode iconbig"></i></td>
                                    <td class="emptyrow"></td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
.height {
    min-height: 200px;
}

.icon {
    font-size: 47px;
    color: #5CB85C;
}

.iconbig {
    font-size: 77px;
    color: #5CB85C;
}

.table > tbody > tr > .emptyrow {
    border-top: none;
}

.table > thead > tr > .emptyrow {
    border-bottom: none;
}

.table > tbody > tr > .highrow {
    border-top: 3px solid;
}
</style>

<!-- Simple Invoice - END -->

</div>

</body>
</html>