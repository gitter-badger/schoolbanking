<?php
require_once('../../../libraries/barcode/drawer/home.php');
    require_once("../../../config/token.php");
	require_once("../../../models/modules.php");
	
require_once('../../handler/class.led.php');
$led = new LED();

               if(isset($_GET['view'])){
		
	           $v = $_GET['view'];
           $stmt = $led->runQuery("SELECT * FROM application WHERE staff_id=:st");
	      $stmt->execute(array(":st"=>$v));
	       $u=$stmt->fetch(PDO::FETCH_ASSOC);
		   $servername = "localhost";

$username = "schoolpos";
$password = "schoolpos";
$dbname = "schoolpos";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT trans_id,loan_id,fname,date1,amount,sign_of_the_receiver,loan_authorized,sign_of_authourity,date FROM loan WHERE fname='".$u['fname']."'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {

    while($row = $result->fetch_assoc()) {
	
	
       
    }
 
} else {
    print "No Datas of loan provided yet";
}

$sql2 = "SELECT loan_id,trans_id,fname,date2,amount_of_loan_obtained,amount_paid,loan_returned,sign_of_receiving_officer,date,debt_owed,status FROM loan_paid WHERE fname='".$u['fname']."'";
$result2 = $conn->query($sql2);

if ($result2->num_rows > 0) {


    while($row2 = $result2->fetch_assoc()) {
       
    }
   
} else {
    print "No Datas of paid loan provided yet";
}

$sql3 = "SELECT salary_id,fname,month,amount,deductions,real_salary,date,sig FROM salary WHERE fname='".$u['fname']."'";
$result3 = $conn->query($sql3);

if ($result3->num_rows > 0) {


    while($row3 = $result3->fetch_assoc()) {
      
    }
  
} else {
    print "No Salary paid to satff yet";
}
$conn->close();

}else{

 print "No Session set";
 }



	         
			
?>



<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8" />
    <title><?php echo $mano["staff_report"] ?></title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />

    <link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.min.css" />
    <link rel="stylesheet" type="text/css" href="font-awesome/css/font-awesome.min.css" />

    <script type="text/javascript" src="js/jquery-1.10.2.min.js"></script>
    <script type="text/javascript" src="bootstrap/js/bootstrap.min.js"></script>
	<script src="../script.js"></script>
		<script src="../../jquery-1.11.3-jquery.min.js"></script>
<script src="../../dist/js/loading.js"></script>
<link href="../../dist/css/loading.css" rel="stylesheet">
</head>
<body>
 <div class="loader"></div>
<div class="container">

<div class="page-header">
    <h1><?php echo $mano["invoice"] ?></h1>
</div>

<!-- Simple Invoice - START -->
<div class="container">
    <div class="row">
        <div class="col-xs-12">
            <div class="text-center">
                <i class="fa fa-search-plus pull-left icon"></i>
                <h2><?php echo $mano["pro"] ?></h2>
            </div>
            <hr>
            <div class="row">
                <div class="col-xs-12 col-md-3 col-lg-3 pull-left">
                    <div class="panel panel-default height">
                        <div class="panel-heading"><?php echo $mano["pro"] ?></div>
                        <div class="panel-body">
                            <strong><?php echo $row["fname"] ?></strong><br>
                            1111 Army Navy Drive<br>
                            Arlington<br>
                            VA<br>
                            <strong>22 203</strong><br>
                        </div>
                    </div>
                </div>
                <div class="col-xs-12 col-md-3 col-lg-3">
                    <div class="panel panel-default height">
                        <div class="panel-heading">Payment Information</div>
                        <div class="panel-body">
                            <strong>Card Name:</strong> Visa<br>
                            <strong>Card Number:</strong> ***** 332<br>
                            <strong>Exp Date:</strong> 09/2020<br>
                        </div>
                    </div>
                </div>
                <div class="col-xs-12 col-md-3 col-lg-3">
                    <div class="panel panel-default height">
                        <div class="panel-heading">Order Preferences</div>
                        <div class="panel-body">
                            <strong>Gift:</strong> No<br>
                            <strong>Express Delivery:</strong> Yes<br>
                            <strong>Insurance:</strong> No<br>
                            <strong>Coupon:</strong> No<br>
                        </div>
                    </div>
                </div>
                <div class="col-xs-12 col-md-3 col-lg-3 pull-right">
                    <div class="panel panel-default height">
                        <div class="panel-heading">Shipping Address</div>
                        <div class="panel-body">
                            <strong>David Peere:</strong><br>
                            1111 Army Navy Drive<br>
                            Arlington<br>
                            VA<br>
                            <strong>22 203</strong><br>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-md-12">
            <div class="panel panel-default">
                <div class="panel-heading">
                    <h3 class="text-center"><strong>Order summary</strong></h3>
                </div>
                <div class="panel-body">
                    <div class="table-responsive">
                        <table class="table table-condensed">
                            <thead>
                                <tr>
                                    <td><strong>Item Name</strong></td>
                                    <td class="text-center"><strong>Item Price</strong></td>
                                    <td class="text-center"><strong>Item Quantity</strong></td>
                                    <td class="text-right"><strong>Total</strong></td>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td>Samsung Galaxy S5</td>
                                    <td class="text-center">$900</td>
                                    <td class="text-center">1</td>
                                    <td class="text-right">$900</td>
                                </tr>
                                <tr>
                                    <td>Samsung Galaxy S5 Extra Battery</td>
                                    <td class="text-center">$30.00</td>
                                    <td class="text-center">1</td>
                                    <td class="text-right">$30.00</td>
                                </tr>
                                <tr>
                                    <td>Screen protector</td>
                                    <td class="text-center">$7</td>
                                    <td class="text-center">4</td>
                                    <td class="text-right">$28</td>
                                </tr>
                                <tr>
                                    <td class="highrow"></td>
                                    <td class="highrow"></td>
                                    <td class="highrow text-center"><strong>Subtotal</strong></td>
                                    <td class="highrow text-right">$958.00</td>
                                </tr>
                                <tr>
                                    <td class="emptyrow"></td>
                                    <td class="emptyrow"></td>
                                    <td class="emptyrow text-center"><strong>Shipping</strong></td>
                                    <td class="emptyrow text-right">$20</td>
                                </tr>
                                <tr>
                                    <td class="emptyrow"><i class="fa fa-barcode iconbig"></i></td>
                                    <td class="emptyrow"></td>
                                    <td class="emptyrow text-center"><strong>Total</strong></td>
                                    <td class="emptyrow text-right">$978.00</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
.height {
    min-height: 200px;
}

.icon {
    font-size: 47px;
    color: #5CB85C;
}

.iconbig {
    font-size: 77px;
    color: #5CB85C;
}

.table > tbody > tr > .emptyrow {
    border-top: none;
}

.table > thead > tr > .emptyrow {
    border-bottom: none;
}

.table > tbody > tr > .highrow {
    border-top: 3px solid;
}
</style>

<!-- Simple Invoice - END -->

</div>

</body>
</html>