<?php
session_start();
    require_once("../../config/token.php");
	require_once("../../models/modules.php");
	
require_once('../handler/class.user.php');
$del = new MANOSOFT();

         if(isset($_GET['del'])){
		
	     $id = $_GET['del'];
		
		 
	     $stmt = $del->runQuery("DELETE FROM pupils WHERE app_id=:id");
	      $stmt->execute(array(":id"=>$id));
		  
		  $stmt22 = $del->runQuery("DELETE FROM users WHERE trans_id=:id");
	      $stmt22->execute(array(":id"=>$id));
		  
		  if($stmt && $stmt22){
		   $del->redirect('payment.php?yess=1');
		   }
		   }
		   ?>
		  