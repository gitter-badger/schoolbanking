<?php
require_once('../../../libraries/barcode/drawer/home.php');
 require_once("../../../config/token.php");
require_once("../../../models/modules.php");
require_once('../../handler/class.sales.php');
$s = new SALES();

if(isset($_GET['id'])){
$id = $_GET['id'];
          $stmt = $s->runQuery("SELECT * FROM sales WHERE app_id=:app");
	      $stmt->execute(array(":app"=>$id));
	      $use=$stmt->fetch(PDO::FETCH_ASSOC);
		  }else{
		  }
		  
?>
<!doctype html>
<html>
	<head>
		<meta charset="utf-8">
		<title><?php echo $use['item_name'] ?>---- Sales Receipt Booklet</title>
		<link rel="stylesheet" href="style.css">
		<link rel="license" href="http://www.manomite.net">
		<script src="script.js"></script>
		<script src="../script.js"></script>
		<script src="../../jquery-1.11.3-jquery.min.js"></script>
<script src="../../dist/js/loading.js"></script>
<link href="../../dist/css/loading.css" rel="stylesheet">
	</head>
	<body>
	 <div class="loader"></div>
		<header>
			<h1><?php echo $mano["invoice"] ?></h1>
			<address>
				<p><?php echo $mano["name5"] ?></p>
				<p><?php echo $mano["address"] ?></p>
				<p><?php echo $mano["tel"] ?></p>
			</address>
			<span><img alt="" src="../../img/header_logo.png" width="60" height="60"></span>
		</header>
		<article>
			<h1>Recipient</h1>
			<address>
				<p><?php echo $use['buyer_name'] ?> Sales Receipt Booklet</p>
			</address>
			<table class="meta">
				<tr>
					<th><?php echo $mano['sales_id'] ?></th>
					<td><?php echo $use['sales_id'] ?></td>
					
				</tr>
				<tr>
					<th>Transaction ID</th>
					<td><?php echo $use['app_id'] ?></td>
				</tr>
				<tr>
					<th><?php echo $mano['cat'] ?></th>
					<td><?php echo $use['category'] ?></td>
				</tr>
				
				<tr>
					<th><span><?php echo $mano['date'] ?></span></th>
					<td><span id="prefix"></span><span><?php echo $use['date'] ?></span></td>
				</tr>
			</table>
			<table class="inventory">
				<thead>
					<tr>
						<th><?php echo $mano['items'] ?></th>
						<th><?php echo $mano['selling'] ?></th>
						<th><?php echo $mano['quantity'] ?></th>
						<th><?php echo $mano['total_tt'] ?></th>
						
					</tr>
				</thead>
				<tbody>
					<tr>
						<td><a class="cut">-</a><?php echo $use['item_name'] ?></td>
						<td>NGN<?php echo $use['selling_price'] ?></td>
						<td><?php echo $use['quantity'] ?></td>
						<td>NGN<?php echo $use['total'] ?></td>
					</tr>
				</tbody>
			</table>
			<a class="add">+</a>
			<table class="balance">
				
				<tr>
					<th><?php echo $mano['amt2'] ?></th>
					<td>NGN<?php echo $use['amount_paid'] ?></td>
				</tr>
				<tr>
					<th><?php echo $mano['balance'] ?></th>
					<td> NGN<?php echo $use['total'] - $use['amount_paid']  ?></td>
				</tr>
			</table>
		</article>
		<aside>
			<h1><span><?php echo $mano['copy'] ?></span></h1>
			<div>
				<p><?php echo $mano['rights'] ?></p>
			</div>
		</aside>
	</body>
</html>