 <?php
 include_once('../modules/u/fpdf/fpdf.php');

require('../modules/table.php');

function Footer()
{
$this->SetY(-15);
$this->SetFont('Arial','I',8);
$this->Cell(0,10,''.$this->PageNo().'/{nb}',0,0,'C');
}
function ChapterTitle($num, $label)
{
$this->SetFont('Arial','',12);
$this->SetFillColor(200,220,255);
$this->Cell(0,6,"$num $label",0,1,'L',true);
$this->Ln(0);
}
function ChapterTitle2($num, $label)
{
$this->SetFont('Arial','',12);
$this->SetFillColor(249,249,249);
$this->Cell(0,1,"$num $label",0,1,'L',true);
$this->Ln(0);
}
$pdf = new PDF();
$pdf->AliasNbPages();
$pdf->AddPage();
$pdf->SetFont('Times','',12);
$pdf->SetTextColor(100,50,100);
$logo = "../modules/image/logo.jpg";
$pdf->Image($logo,90,17,20);
$pdf->SetFont('Arial','B',18);
$pdf->Ln(1);
$pdf->Cell(180,5,'Emerald British Nur/Pry School',0,1,'C');

$pdf->Ln(24);
$pdf->SetTextColor(139,0,0);
$pdf->SetFont('Arial','',14);
$pdf->Cell(180,5,'School Address',0,1,'C');
$pdf->Ln(2);
$pdf->Cell(180,5,'TEL: 08164649834',0,1,'C');
$pdf->Ln(2);
$pdf->SetFont('Arial','',9);
$pdf->Cell(180,5,'Website: www.e-emerald.org',0,1,'C');
$pdf->Ln(3);
$pdf->Cell(0,0,0,1,'C');
$pdf->Ln(5);
$pdf->SetTextColor(100,50,100);
$pdf->SetFont('Arial','B',12);
$pdf->Cell(180,5,'STAFF APPLICATION BOOKLET',0,1,'C');
$pdf->Ln(6);
$pdf->SetFont('Times','',12);
$pdf->Cell(180,5,'Name:-------------------------------------------------',0,1,'L');
$pdf->Ln(2);
$pdf->Cell(180,5,'Address:----------------------------------------------',0,1,'L');
$pdf->Ln(2);
$pdf->Cell(180,5,'Phone:-------------------------------------------------',0,1,'L');
$pdf->Ln(2);
$pdf->Cell(180,5,'Employment Date:-----------------------------------',0,1,'L');
$pdf->Ln(2);
$pdf->Cell(180,5,'Department:-------------------------------------------',0,1,'L');
$pdf->Ln(2);
$pdf->Cell(180,5,'Qualification:----------------------------------------- ',0,1,'L');
$pdf->Ln(2);
$pdf->Cell(180,5,'File NO:------------------------------------------------',0,1,'L');
$pdf->Ln(2);
$pdf->Cell(180,5,'Designation:------------------------------------------- ',0,1,'L');
$pdf->Ln(120);
$pdf->Cell(180,5,'* For more informations or complaints contact the school management.',0,1,'C');
$pdf->Ln(1);
$pdf->SetTextColor(105,105,105);
$pdf->SetFont('Arial','',7);
$pdf->Cell(180,5,'Printed from Emerald British Nur/Pry School Inventory Software',0,1,'C');
$pdf->Ln(2);
$pdf->SetFont('Times','',7);
$pdf->Ln(2);
$pdf->Image($logo,160,70,50);
$pdf->Cell(0,0,'',0,1,'R');
$filename="staff-application.pdf";
$pdf->Output($filename,'I');
?>