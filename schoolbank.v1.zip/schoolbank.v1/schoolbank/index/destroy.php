<?php
require_once('../handler/session.php');
require_once('info.php');
   session_destroy();
unset($_SESSION['id'],$_SESSION['class'],$_SESSION['sess']);

?>